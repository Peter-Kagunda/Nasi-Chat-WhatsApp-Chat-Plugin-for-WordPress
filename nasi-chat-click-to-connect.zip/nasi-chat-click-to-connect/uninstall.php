<?php
/**
 * Uninstall handler.
 *
 * Fired only when the plugin is deleted (not merely deactivated) via
 * the WordPress admin. Removes all options, custom tables and scheduled
 * events created by the plugin.
 *
 * @package Nasi_Chat
 */

// If this file is not called by WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove plugin options.
delete_option( 'chnasi_settings' );
delete_option( 'chnasi_db_version' );

// Remove the custom click-tracking table.
require_once plugin_dir_path( __FILE__ ) . 'includes/class-chnasi-db.php';
CHNASI_DB::drop_tables();

// Clear any scheduled cron events.
wp_clear_scheduled_hook( 'chnasi_daily_cleanup' );
