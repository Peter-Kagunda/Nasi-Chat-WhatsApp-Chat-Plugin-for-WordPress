<?php
/**
 * Business hours settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$chnasi_timezones = timezone_identifiers_list();
?>
<section class="chnasi-tab-panel" data-tab-panel="hours">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Business Hours Scheduling', 'nasi-chat-click-to-connect' ); ?></h2>

		<div class="chnasi-field-row chnasi-field-row-inline">
			<label class="chnasi-switch">
				<input type="checkbox" id="chnasi-field-hours-enabled" data-setting="business_hours_enabled" <?php checked( $options['business_hours_enabled'] ); ?> />
				<span class="chnasi-switch-slider"></span>
			</label>
			<span><?php esc_html_e( 'Only show availability as "online" during set hours', 'nasi-chat-click-to-connect' ); ?></span>
		</div>

		<div class="chnasi-field-row chnasi-field-row-narrow">
			<label for="chnasi-field-timezone"><?php esc_html_e( 'Timezone', 'nasi-chat-click-to-connect' ); ?></label>
			<select id="chnasi-field-timezone" data-setting="timezone_string">
				<?php foreach ( $chnasi_timezones as $chnasi_tz ) : ?>
					<option value="<?php echo esc_attr( $chnasi_tz ); ?>" <?php selected( $options['timezone_string'], $chnasi_tz ); ?>><?php echo esc_html( $chnasi_tz ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>

		<table class="chnasi-hours-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Day', 'nasi-chat-click-to-connect' ); ?></th>
					<th><?php esc_html_e( 'Open', 'nasi-chat-click-to-connect' ); ?></th>
					<th><?php esc_html_e( 'Start', 'nasi-chat-click-to-connect' ); ?></th>
					<th><?php esc_html_e( 'End', 'nasi-chat-click-to-connect' ); ?></th>
				</tr>
			</thead>
			<tbody id="chnasi-hours-tbody">
				<?php foreach ( $chnasi_days_of_week as $chnasi_day_key => $chnasi_day_label ) : ?>
					<?php $chnasi_day_data = $options['business_hours'][ $chnasi_day_key ]; ?>
					<tr data-day="<?php echo esc_attr( $chnasi_day_key ); ?>">
						<td><?php echo esc_html( $chnasi_day_label ); ?></td>
						<td>
							<label class="chnasi-switch chnasi-switch-sm">
								<input type="checkbox" class="chnasi-hours-enabled" <?php checked( $chnasi_day_data['enabled'] ); ?> />
								<span class="chnasi-switch-slider"></span>
							</label>
						</td>
						<td><input type="time" class="chnasi-hours-start" value="<?php echo esc_attr( $chnasi_day_data['start'] ); ?>" /></td>
						<td><input type="time" class="chnasi-hours-end" value="<?php echo esc_attr( $chnasi_day_data['end'] ); ?>" /></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<input type="hidden" id="chnasi-field-business-hours" data-setting="business_hours" value="<?php echo esc_attr( wp_json_encode( $options['business_hours'] ) ); ?>" />
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'When Offline', 'nasi-chat-click-to-connect' ); ?></h2>
		<div class="chnasi-field-row">
			<div class="chnasi-choice-group" data-setting-group="offline_behavior">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'show_offline_message' === $options['offline_behavior'] ) ? 'is-active' : ''; ?>" data-choice-value="show_offline_message"><?php esc_html_e( 'Show Offline Message', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'hide_button' === $options['offline_behavior'] ) ? 'is-active' : ''; ?>" data-choice-value="hide_button"><?php esc_html_e( 'Hide Button Entirely', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-offline-behavior" data-setting="offline_behavior" value="<?php echo esc_attr( $options['offline_behavior'] ); ?>" />
		</div>

		<div class="chnasi-field-row">
			<label for="chnasi-field-offline-message"><?php esc_html_e( 'Offline Message', 'nasi-chat-click-to-connect' ); ?></label>
			<textarea id="chnasi-field-offline-message" data-setting="offline_message" rows="3"><?php echo esc_textarea( $options['offline_message'] ); ?></textarea>
		</div>
	</div>

</section>
