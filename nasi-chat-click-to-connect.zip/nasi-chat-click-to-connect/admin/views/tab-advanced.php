<?php
/**
 * Advanced settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="advanced">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Plugin Information', 'nasi-chat-click-to-connect' ); ?></h2>
		<table class="chnasi-info-table">
			<tr>
				<th><?php esc_html_e( 'Plugin Name', 'nasi-chat-click-to-connect' ); ?></th>
				<td><?php esc_html_e( 'Nasi Chat - Click to Connect', 'nasi-chat-click-to-connect' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Version', 'nasi-chat-click-to-connect' ); ?></th>
				<td><?php echo esc_html( CHNASI_VERSION ); ?></td>
			</tr>
		</table>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Nasi Chat Pro', 'nasi-chat-click-to-connect' ); ?></h2>
		<p class="chnasi-card-desc"><?php esc_html_e( 'Need more? Nasi Chat Pro adds per-agent online/offline status, brand colours, multilingual support, Telegram/Messenger/SMS/email buttons, a pre-chat lead form with a leads dashboard, CSV export, email notifications, signed webhooks and shortcodes.', 'nasi-chat-click-to-connect' ); ?></p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( 'https://peterkagunda.com/product/nasi-chat-pro/' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get Nasi Chat Pro', 'nasi-chat-click-to-connect' ); ?></a>
		</p>
	</div>

</section>
