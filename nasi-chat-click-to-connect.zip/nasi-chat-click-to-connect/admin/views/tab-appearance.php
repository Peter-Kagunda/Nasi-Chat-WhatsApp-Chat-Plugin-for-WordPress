<?php
/**
 * Appearance settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="appearance">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Position &amp; Size', 'nasi-chat-click-to-connect' ); ?></h2>

		<div class="chnasi-field-row">
			<label><?php esc_html_e( 'Screen Position', 'nasi-chat-click-to-connect' ); ?></label>
			<div class="chnasi-choice-group" data-setting-group="position">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'right' === $options['position'] ) ? 'is-active' : ''; ?>" data-choice-value="right">
					<?php esc_html_e( 'Bottom Right', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'left' === $options['position'] ) ? 'is-active' : ''; ?>" data-choice-value="left">
					<?php esc_html_e( 'Bottom Left', 'nasi-chat-click-to-connect' ); ?>
				</button>
			</div>
			<input type="hidden" id="chnasi-field-position" data-setting="position" value="<?php echo esc_attr( $options['position'] ); ?>" />
		</div>

		<div class="chnasi-field-row">
			<label><?php esc_html_e( 'Button Size', 'nasi-chat-click-to-connect' ); ?></label>
			<div class="chnasi-choice-group" data-setting-group="button_size">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'small' === $options['button_size'] ) ? 'is-active' : ''; ?>" data-choice-value="small"><?php esc_html_e( 'Small', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'medium' === $options['button_size'] ) ? 'is-active' : ''; ?>" data-choice-value="medium"><?php esc_html_e( 'Medium', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'large' === $options['button_size'] ) ? 'is-active' : ''; ?>" data-choice-value="large"><?php esc_html_e( 'Large', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-button-size" data-setting="button_size" value="<?php echo esc_attr( $options['button_size'] ); ?>" />
		</div>

		<div class="chnasi-field-row chnasi-field-row-narrow">
			<label for="chnasi-field-zindex"><?php esc_html_e( 'Z-Index (layer order)', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="number" id="chnasi-field-zindex" data-setting="z_index" min="1" max="999999" value="<?php echo esc_attr( $options['z_index'] ); ?>" />
		</div>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Colors &amp; Animation', 'nasi-chat-click-to-connect' ); ?></h2>

		<div class="chnasi-grid-2">
			<div class="chnasi-field-row">
				<label for="chnasi-field-bg-color"><?php esc_html_e( 'Button Color', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" id="chnasi-field-bg-color" class="chnasi-color-picker" data-setting="button_bg_color" value="<?php echo esc_attr( $options['button_bg_color'] ); ?>" />
			</div>
			<div class="chnasi-field-row">
				<label for="chnasi-field-icon-color"><?php esc_html_e( 'Icon Color', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" id="chnasi-field-icon-color" class="chnasi-color-picker" data-setting="icon_color" value="<?php echo esc_attr( $options['icon_color'] ); ?>" />
			</div>
		</div>

		<div class="chnasi-field-row">
			<label for="chnasi-field-animation"><?php esc_html_e( 'Attention Animation', 'nasi-chat-click-to-connect' ); ?></label>
			<select id="chnasi-field-animation" data-setting="animation">
				<option value="none" <?php selected( $options['animation'], 'none' ); ?>><?php esc_html_e( 'None', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="pulse" <?php selected( $options['animation'], 'pulse' ); ?>><?php esc_html_e( 'Pulse', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="bounce" <?php selected( $options['animation'], 'bounce' ); ?>><?php esc_html_e( 'Bounce', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="shake" <?php selected( $options['animation'], 'shake' ); ?>><?php esc_html_e( 'Shake', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="fade" <?php selected( $options['animation'], 'fade' ); ?>><?php esc_html_e( 'Fade Pulse', 'nasi-chat-click-to-connect' ); ?></option>
			</select>
		</div>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Icon', 'nasi-chat-click-to-connect' ); ?></h2>

		<div class="chnasi-field-row">
			<div class="chnasi-choice-group" data-setting-group="icon_type">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'default' === $options['icon_type'] ) ? 'is-active' : ''; ?>" data-choice-value="default"><?php esc_html_e( 'Default WhatsApp Icon', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'custom' === $options['icon_type'] ) ? 'is-active' : ''; ?>" data-choice-value="custom"><?php esc_html_e( 'Custom Icon', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-icon-type" data-setting="icon_type" value="<?php echo esc_attr( $options['icon_type'] ); ?>" />
		</div>

		<div class="chnasi-field-row" id="chnasi-custom-icon-row" style="<?php echo ( 'custom' === $options['icon_type'] ) ? '' : 'display:none;'; ?>">
			<label><?php esc_html_e( 'Custom Icon Image', 'nasi-chat-click-to-connect' ); ?></label>
			<div class="chnasi-media-picker">
				<img id="chnasi-custom-icon-preview" src="<?php echo esc_url( $options['custom_icon_url'] ); ?>" alt="" style="<?php echo empty( $options['custom_icon_url'] ) ? 'display:none;' : ''; ?>" />
				<button type="button" class="button" id="chnasi-upload-icon-btn"><?php esc_html_e( 'Choose Image', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="button-link chnasi-remove-icon-btn" id="chnasi-remove-icon-btn" style="<?php echo empty( $options['custom_icon_url'] ) ? 'display:none;' : ''; ?>"><?php esc_html_e( 'Remove', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-custom-icon-url" data-setting="custom_icon_url" value="<?php echo esc_attr( $options['custom_icon_url'] ); ?>" />
		</div>
	</div>

</section>
