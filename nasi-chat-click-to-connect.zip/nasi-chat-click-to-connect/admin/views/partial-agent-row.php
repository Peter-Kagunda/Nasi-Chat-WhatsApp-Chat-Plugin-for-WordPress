<?php
/**
 * Repeatable agent row markup.
 *
 * When included directly it may receive $chnasi_agent (array); when used inside
 * the <template> for JS cloning, $chnasi_agent is intentionally undefined and
 * every field renders empty.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$chnasi_agent = isset( $chnasi_agent ) && is_array( $chnasi_agent ) ? $chnasi_agent : array(
	'id'           => '',
	'name'         => '',
	'role'         => '',
	'phone_number' => '',
	'message'      => '',
	'avatar_url'   => '',
);
?>
<div class="chnasi-agent-card" data-agent-row data-agent-id="<?php echo esc_attr( $chnasi_agent['id'] ); ?>">
	<div class="chnasi-agent-card-avatar">
		<img class="chnasi-agent-card-avatar-img" src="<?php echo esc_url( $chnasi_agent['avatar_url'] ); ?>" alt="" style="<?php echo empty( $chnasi_agent['avatar_url'] ) ? 'display:none;' : ''; ?>" />
		<span class="chnasi-agent-card-avatar-placeholder dashicons dashicons-admin-users" style="<?php echo empty( $chnasi_agent['avatar_url'] ) ? '' : 'display:none;'; ?>"></span>
		<button type="button" class="button chnasi-agent-avatar-btn"><?php esc_html_e( 'Photo', 'nasi-chat-click-to-connect' ); ?></button>
		<input type="hidden" class="chnasi-agent-avatar-url" value="<?php echo esc_attr( $chnasi_agent['avatar_url'] ); ?>" />
	</div>

	<div class="chnasi-agent-card-fields">
		<div class="chnasi-grid-2">
			<div class="chnasi-field-row">
				<label><?php esc_html_e( 'Name', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" class="chnasi-agent-name" value="<?php echo esc_attr( $chnasi_agent['name'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Sarah Njeri', 'nasi-chat-click-to-connect' ); ?>" />
			</div>
			<div class="chnasi-field-row">
				<label><?php esc_html_e( 'Role / Department', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" class="chnasi-agent-role" value="<?php echo esc_attr( $chnasi_agent['role'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Sales Support', 'nasi-chat-click-to-connect' ); ?>" />
			</div>
		</div>
		<div class="chnasi-grid-2">
			<div class="chnasi-field-row">
				<label><?php esc_html_e( 'WhatsApp Number', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" class="chnasi-agent-phone" value="<?php echo esc_attr( $chnasi_agent['phone_number'] ); ?>" placeholder="254700000000" />
			</div>
			<div class="chnasi-field-row">
				<label><?php esc_html_e( 'Prefilled Message', 'nasi-chat-click-to-connect' ); ?></label>
				<input type="text" class="chnasi-agent-message" value="<?php echo esc_attr( $chnasi_agent['message'] ); ?>" />
			</div>
		</div>
	</div>

	<button type="button" class="chnasi-agent-remove-btn" aria-label="<?php esc_attr_e( 'Remove agent', 'nasi-chat-click-to-connect' ); ?>">
		<span class="dashicons dashicons-trash"></span>
	</button>
</div>
