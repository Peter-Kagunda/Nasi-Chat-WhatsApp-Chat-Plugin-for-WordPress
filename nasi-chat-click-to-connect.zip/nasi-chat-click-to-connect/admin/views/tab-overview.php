<?php
/**
 * Overview tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel is-active" data-tab-panel="overview">

	<div class="chnasi-stat-grid">
		<div class="chnasi-stat-card">
			<span class="chnasi-stat-icon chnasi-stat-icon-green dashicons dashicons-format-chat"></span>
			<div>
				<p class="chnasi-stat-value"><?php echo esc_html( number_format_i18n( $total_clicks ) ); ?></p>
				<p class="chnasi-stat-label"><?php esc_html_e( 'Total Clicks', 'nasi-chat-click-to-connect' ); ?></p>
			</div>
		</div>
		<div class="chnasi-stat-card">
			<span class="chnasi-stat-icon chnasi-stat-icon-teal dashicons dashicons-calendar-alt"></span>
			<div>
				<p class="chnasi-stat-value"><?php echo esc_html( number_format_i18n( $clicks_7_days ) ); ?></p>
				<p class="chnasi-stat-label"><?php esc_html_e( 'Clicks (Last 7 Days)', 'nasi-chat-click-to-connect' ); ?></p>
			</div>
		</div>
		<div class="chnasi-stat-card">
			<span class="chnasi-stat-icon chnasi-stat-icon-dark dashicons dashicons-groups"></span>
			<div>
				<p class="chnasi-stat-value"><?php echo esc_html( count( $options['agents'] ) ); ?></p>
				<p class="chnasi-stat-label"><?php esc_html_e( 'Active Agents', 'nasi-chat-click-to-connect' ); ?></p>
			</div>
		</div>
		<div class="chnasi-stat-card">
			<span class="chnasi-stat-icon chnasi-stat-icon-amber dashicons dashicons-clock"></span>
			<div>
				<p class="chnasi-stat-value" id="chnasi-status-pill">
					<?php echo $options['business_hours_enabled'] ? esc_html__( 'Scheduled', 'nasi-chat-click-to-connect' ) : esc_html__( 'Always On', 'nasi-chat-click-to-connect' ); ?>
				</p>
				<p class="chnasi-stat-label"><?php esc_html_e( 'Availability Mode', 'nasi-chat-click-to-connect' ); ?></p>
			</div>
		</div>
	</div>

	<div class="chnasi-card">
		<div class="chnasi-card-header">
			<h2><?php esc_html_e( 'Clicks Over Time', 'nasi-chat-click-to-connect' ); ?></h2>
			<select id="chnasi-chart-range">
				<option value="7"><?php esc_html_e( 'Last 7 days', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="14" selected="selected"><?php esc_html_e( 'Last 14 days', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="30"><?php esc_html_e( 'Last 30 days', 'nasi-chat-click-to-connect' ); ?></option>
				<option value="90"><?php esc_html_e( 'Last 90 days', 'nasi-chat-click-to-connect' ); ?></option>
			</select>
		</div>
		<div class="chnasi-chart-wrap">
			<canvas id="chnasi-clicks-chart" height="90"></canvas>
			<p id="chnasi-chart-empty" class="chnasi-empty-note" style="display:none;">
				<?php esc_html_e( 'No click data yet. Once visitors start clicking your WhatsApp button, activity will appear here.', 'nasi-chat-click-to-connect' ); ?>
			</p>
		</div>
	</div>

	<div class="chnasi-grid-2">
		<div class="chnasi-card">
			<h2><?php esc_html_e( 'Quick Setup Checklist', 'nasi-chat-click-to-connect' ); ?></h2>
			<ul class="chnasi-checklist">
				<li class="<?php echo ! empty( $options['phone_number'] ) ? 'is-done' : ''; ?>">
					<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'WhatsApp number configured', 'nasi-chat-click-to-connect' ); ?>
				</li>
				<li class="<?php echo ! empty( $options['welcome_message'] ) ? 'is-done' : ''; ?>">
					<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Welcome message set', 'nasi-chat-click-to-connect' ); ?>
				</li>
				<li class="<?php echo $options['tooltip_enabled'] ? 'is-done' : ''; ?>">
					<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Chat tooltip enabled', 'nasi-chat-click-to-connect' ); ?>
				</li>
				<li class="<?php echo $options['click_tracking_enabled'] ? 'is-done' : ''; ?>">
					<span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Click analytics enabled', 'nasi-chat-click-to-connect' ); ?>
				</li>
			</ul>
		</div>

		<div class="chnasi-card">
			<h2><?php esc_html_e( 'Top Agents', 'nasi-chat-click-to-connect' ); ?></h2>
			<div id="chnasi-top-agents-list" class="chnasi-top-agents">
				<p class="chnasi-empty-note"><?php esc_html_e( 'Loading...', 'nasi-chat-click-to-connect' ); ?></p>
			</div>
		</div>
	</div>

</section>
