<?php
/**
 * Analytics tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="analytics">

	<div class="chnasi-card">
		<div class="chnasi-card-header">
			<h2><?php esc_html_e( 'Clicks by Agent', 'nasi-chat-click-to-connect' ); ?></h2>
		</div>
		<table class="chnasi-data-table" id="chnasi-agent-breakdown-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Agent / Button', 'nasi-chat-click-to-connect' ); ?></th>
					<th><?php esc_html_e( 'Total Clicks', 'nasi-chat-click-to-connect' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="2" class="chnasi-empty-note"><?php esc_html_e( 'Loading...', 'nasi-chat-click-to-connect' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="chnasi-card chnasi-card-danger">
		<h2><?php esc_html_e( 'Reset Analytics', 'nasi-chat-click-to-connect' ); ?></h2>
		<p class="chnasi-card-desc"><?php esc_html_e( 'Permanently delete all recorded click data. This cannot be undone.', 'nasi-chat-click-to-connect' ); ?></p>
		<button type="button" class="button" id="chnasi-reset-stats-btn"><?php esc_html_e( 'Clear All Click Data', 'nasi-chat-click-to-connect' ); ?></button>
	</div>

</section>
