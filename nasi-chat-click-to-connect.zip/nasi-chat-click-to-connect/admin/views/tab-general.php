<?php
/**
 * General settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="general">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'WhatsApp Details', 'nasi-chat-click-to-connect' ); ?></h2>
		<p class="chnasi-card-desc"><?php esc_html_e( 'The default number visitors reach when multi-agent routing is off, or when they contact your main line.', 'nasi-chat-click-to-connect' ); ?></p>

		<div class="chnasi-field-row">
			<label for="chnasi-field-phone"><?php esc_html_e( 'WhatsApp Phone Number', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="text" id="chnasi-field-phone" data-setting="phone_number" value="<?php echo esc_attr( $options['phone_number'] ); ?>" placeholder="e.g. 254722207737" />
			<p class="chnasi-field-hint"><?php esc_html_e( 'Include the country code, digits only (no + or spaces required).', 'nasi-chat-click-to-connect' ); ?></p>
		</div>

		<div class="chnasi-field-row">
			<label for="chnasi-field-welcome"><?php esc_html_e( 'Prefilled Welcome Message', 'nasi-chat-click-to-connect' ); ?></label>
			<textarea id="chnasi-field-welcome" data-setting="welcome_message" rows="3"><?php echo esc_textarea( $options['welcome_message'] ); ?></textarea>
			<p class="chnasi-field-hint"><?php esc_html_e( 'This text is pre-filled in the chat when a visitor clicks the button.', 'nasi-chat-click-to-connect' ); ?></p>
		</div>

		<div class="chnasi-field-row">
			<label for="chnasi-field-button-label"><?php esc_html_e( 'Panel Title (multi-agent mode)', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="text" id="chnasi-field-button-label" data-setting="button_label" value="<?php echo esc_attr( $options['button_label'] ); ?>" />
		</div>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Chat Tooltip', 'nasi-chat-click-to-connect' ); ?></h2>
		<div class="chnasi-field-row chnasi-field-row-inline">
			<label class="chnasi-switch">
				<input type="checkbox" id="chnasi-field-tooltip-enabled" data-setting="tooltip_enabled" <?php checked( $options['tooltip_enabled'] ); ?> />
				<span class="chnasi-switch-slider"></span>
			</label>
			<span><?php esc_html_e( 'Show a chat bubble tooltip near the button', 'nasi-chat-click-to-connect' ); ?></span>
		</div>

		<div class="chnasi-field-row">
			<label for="chnasi-field-tooltip-text"><?php esc_html_e( 'Tooltip Text', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="text" id="chnasi-field-tooltip-text" data-setting="tooltip_text" value="<?php echo esc_attr( $options['tooltip_text'] ); ?>" />
		</div>

		<div class="chnasi-field-row chnasi-field-row-narrow">
			<label for="chnasi-field-tooltip-delay"><?php esc_html_e( 'Show After (seconds)', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="number" id="chnasi-field-tooltip-delay" data-setting="tooltip_delay" min="0" max="60" value="<?php echo esc_attr( $options['tooltip_delay'] ); ?>" />
		</div>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Tracking', 'nasi-chat-click-to-connect' ); ?></h2>

		<div class="chnasi-field-row chnasi-field-row-inline">
			<label class="chnasi-switch">
				<input type="checkbox" id="chnasi-field-click-tracking" data-setting="click_tracking_enabled" <?php checked( $options['click_tracking_enabled'] ); ?> />
				<span class="chnasi-switch-slider"></span>
			</label>
			<span><?php esc_html_e( 'Log button clicks for the Analytics dashboard', 'nasi-chat-click-to-connect' ); ?></span>
		</div>

		<div class="chnasi-field-row chnasi-field-row-inline">
			<label class="chnasi-switch">
				<input type="checkbox" id="chnasi-field-ga-tracking" data-setting="ga_tracking_enabled" <?php checked( $options['ga_tracking_enabled'] ); ?> />
				<span class="chnasi-switch-slider"></span>
			</label>
			<span><?php esc_html_e( 'Fire a Google Analytics (gtag) event on click', 'nasi-chat-click-to-connect' ); ?></span>
		</div>

		<div class="chnasi-field-row chnasi-field-row-narrow">
			<label for="chnasi-field-ga-event"><?php esc_html_e( 'GA Event Name', 'nasi-chat-click-to-connect' ); ?></label>
			<input type="text" id="chnasi-field-ga-event" data-setting="ga_event_name" value="<?php echo esc_attr( $options['ga_event_name'] ); ?>" />
			<p class="chnasi-field-hint"><?php esc_html_e( 'Requires gtag.js to already be loaded on your site.', 'nasi-chat-click-to-connect' ); ?></p>
		</div>
	</div>

</section>
