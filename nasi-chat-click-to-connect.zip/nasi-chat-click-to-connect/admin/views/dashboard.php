<?php
/**
 * Admin dashboard view.
 *
 * Expects: $options (array), $total_clicks (int), $clicks_7_days (int),
 * $pages (array of WP_Post), $posts (array of WP_Post).
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$chnasi_days_of_week = array(
	'monday'    => __( 'Monday', 'nasi-chat-click-to-connect' ),
	'tuesday'   => __( 'Tuesday', 'nasi-chat-click-to-connect' ),
	'wednesday' => __( 'Wednesday', 'nasi-chat-click-to-connect' ),
	'thursday'  => __( 'Thursday', 'nasi-chat-click-to-connect' ),
	'friday'    => __( 'Friday', 'nasi-chat-click-to-connect' ),
	'saturday'  => __( 'Saturday', 'nasi-chat-click-to-connect' ),
	'sunday'    => __( 'Sunday', 'nasi-chat-click-to-connect' ),
);
?>
<div class="wrap chnasi-wrap">
	<div id="chnasi-app" class="chnasi-app">

		<!-- Top bar -->
		<div class="chnasi-topbar">
			<div class="chnasi-topbar-brand">
				<span class="chnasi-brand-badge">
					<svg width="22" height="22" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="1024" rx="265" fill="#25D366"/><path d="M522 141C320.419 141 157 304.419 157 506C157 572.322 174.689 634.507 205.606 688.101L157 871L346.617 826.173C398.664 854.744 458.429 871 522 871C723.581 871 887 707.581 887 506C887 304.419 723.581 141 522 141ZM522 805.624C460.998 805.624 404.254 787.388 356.919 756.079L244.891 784.61L276.314 677.536C242.322 628.944 222.376 569.801 222.376 506C222.376 340.52 356.52 206.376 522 206.376C687.48 206.376 821.624 340.52 821.624 506C821.624 671.48 687.48 805.624 522 805.624Z" fill="white"/><path d="M607.527 554.187L695.836 595.825C699.892 597.737 702.488 601.847 702.123 606.315C701.163 617.934 696.506 641.226 675.626 662.099C616.692 721.033 510.876 654.36 506.577 651.778C480.554 637.799 455.815 619.09 432.374 595.642C408.933 572.201 390.217 547.462 376.238 521.439C373.656 517.14 306.983 411.317 365.917 352.39C386.796 331.51 410.082 326.853 421.701 325.893C426.169 325.528 430.279 328.124 432.192 332.18L473.829 420.489C475.802 424.667 474.937 429.635 471.666 432.899L440.627 463.938C433.915 470.65 431.942 481.1 436.565 489.393C447.887 509.705 463.115 529.259 480.764 547.252C498.757 564.894 518.318 580.129 538.623 591.451C546.917 596.075 557.366 594.108 564.078 587.389L595.117 556.35C598.381 553.086 603.35 552.221 607.527 554.187Z" fill="white"/></svg>
				</span>
				<div>
					<h1><?php esc_html_e( 'Nasi Chat - Click to Connect', 'nasi-chat-click-to-connect' ); ?></h1>
					<p><?php esc_html_e( 'Floating chat button settings', 'nasi-chat-click-to-connect' ); ?></p>
				</div>
			</div>
			<div class="chnasi-topbar-actions">
				<label class="chnasi-master-toggle">
					<span class="chnasi-switch">
						<input type="checkbox" id="chnasi-field-enabled" data-setting="enabled" <?php checked( $options['enabled'] ); ?> />
						<span class="chnasi-switch-slider"></span>
					</span>
					<span><?php esc_html_e( 'Button Enabled', 'nasi-chat-click-to-connect' ); ?></span>
				</label>
				<span id="chnasi-save-status" class="chnasi-save-status" aria-live="polite"></span>
				<button type="button" id="chnasi-save-btn" class="button button-primary chnasi-btn-save">
					<span class="dashicons dashicons-yes-alt"></span>
					<?php esc_html_e( 'Save Changes', 'nasi-chat-click-to-connect' ); ?>
				</button>
			</div>
		</div>

		<div class="chnasi-body">

			<!-- Side navigation -->
			<nav class="chnasi-nav">
				<button type="button" class="chnasi-nav-item is-active" data-tab="overview">
					<span class="dashicons dashicons-chart-bar"></span> <?php esc_html_e( 'Overview', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="general">
					<span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'General', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="appearance">
					<span class="dashicons dashicons-admin-appearance"></span> <?php esc_html_e( 'Appearance', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="visibility">
					<span class="dashicons dashicons-visibility"></span> <?php esc_html_e( 'Visibility', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="hours">
					<span class="dashicons dashicons-clock"></span> <?php esc_html_e( 'Business Hours', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="agents">
					<span class="dashicons dashicons-groups"></span> <?php esc_html_e( 'Agents', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="analytics">
					<span class="dashicons dashicons-chart-line"></span> <?php esc_html_e( 'Analytics', 'nasi-chat-click-to-connect' ); ?>
				</button>
				<button type="button" class="chnasi-nav-item" data-tab="advanced">
					<span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e( 'Advanced', 'nasi-chat-click-to-connect' ); ?>
				</button>

				<div class="chnasi-nav-footer">
					<div class="chnasi-preview-card">
						<p class="chnasi-preview-label"><?php esc_html_e( 'Live Preview', 'nasi-chat-click-to-connect' ); ?></p>
						<div class="chnasi-preview-stage">
							<div id="chnasi-preview-bubble" class="chnasi-preview-bubble">
								<svg width="60%" height="60%" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path d="M522 141C320.419 141 157 304.419 157 506C157 572.322 174.689 634.507 205.606 688.101L157 871L346.617 826.173C398.664 854.744 458.429 871 522 871C723.581 871 887 707.581 887 506C887 304.419 723.581 141 522 141ZM522 805.624C460.998 805.624 404.254 787.388 356.919 756.079L244.891 784.61L276.314 677.536C242.322 628.944 222.376 569.801 222.376 506C222.376 340.52 356.52 206.376 522 206.376C687.48 206.376 821.624 340.52 821.624 506C821.624 671.48 687.48 805.624 522 805.624Z" fill="#fff"/><path d="M607.527 554.187L695.836 595.825C699.892 597.737 702.488 601.847 702.123 606.315C701.163 617.934 696.506 641.226 675.626 662.099C616.692 721.033 510.876 654.36 506.577 651.778C480.554 637.799 455.815 619.09 432.374 595.642C408.933 572.201 390.217 547.462 376.238 521.439C373.656 517.14 306.983 411.317 365.917 352.39C386.796 331.51 410.082 326.853 421.701 325.893C426.169 325.528 430.279 328.124 432.192 332.18L473.829 420.489C475.802 424.667 474.937 429.635 471.666 432.899L440.627 463.938C433.915 470.65 431.942 481.1 436.565 489.393C447.887 509.705 463.115 529.259 480.764 547.252C498.757 564.894 518.318 580.129 538.623 591.451C546.917 596.075 557.366 594.108 564.078 587.389L595.117 556.35C598.381 553.086 603.35 552.221 607.527 554.187Z" fill="#fff"/></svg>
							</div>
						</div>
					</div>
				</div>
			</nav>

			<!-- Main panel area -->
			<main class="chnasi-panels">

				<?php require __DIR__ . '/tab-overview.php'; ?>
				<?php require __DIR__ . '/tab-general.php'; ?>
				<?php require __DIR__ . '/tab-appearance.php'; ?>
				<?php require __DIR__ . '/tab-visibility.php'; ?>
				<?php require __DIR__ . '/tab-hours.php'; ?>
				<?php require __DIR__ . '/tab-agents.php'; ?>
				<?php require __DIR__ . '/tab-analytics.php'; ?>
				<?php require __DIR__ . '/tab-advanced.php'; ?>

			</main>
		</div>
	</div>

	<!-- Repeatable agent row template (cloned via JS). -->
	<?php
	// The agents loop leaves its last agent in this variable; clear it so the template renders blank.
	unset( $chnasi_agent );
	?>
	<template id="chnasi-agent-row-template">
		<?php require __DIR__ . '/partial-agent-row.php'; ?>
	</template>
</div>
