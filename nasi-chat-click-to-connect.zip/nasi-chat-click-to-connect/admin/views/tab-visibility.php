<?php
/**
 * Visibility settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="visibility">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Device Targeting', 'nasi-chat-click-to-connect' ); ?></h2>
		<div class="chnasi-field-row">
			<div class="chnasi-choice-group" data-setting-group="show_on">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'all' === $options['show_on'] ) ? 'is-active' : ''; ?>" data-choice-value="all"><?php esc_html_e( 'All Devices', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'desktop' === $options['show_on'] ) ? 'is-active' : ''; ?>" data-choice-value="desktop"><?php esc_html_e( 'Desktop Only', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'mobile' === $options['show_on'] ) ? 'is-active' : ''; ?>" data-choice-value="mobile"><?php esc_html_e( 'Mobile Only', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-show-on" data-setting="show_on" value="<?php echo esc_attr( $options['show_on'] ); ?>" />
		</div>
	</div>

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Page Display Rules', 'nasi-chat-click-to-connect' ); ?></h2>
		<div class="chnasi-field-row">
			<div class="chnasi-choice-group" data-setting-group="display_rule">
				<button type="button" class="chnasi-choice-btn <?php echo ( 'all' === $options['display_rule'] ) ? 'is-active' : ''; ?>" data-choice-value="all"><?php esc_html_e( 'Show Everywhere', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'include' === $options['display_rule'] ) ? 'is-active' : ''; ?>" data-choice-value="include"><?php esc_html_e( 'Only on Selected Pages', 'nasi-chat-click-to-connect' ); ?></button>
				<button type="button" class="chnasi-choice-btn <?php echo ( 'exclude' === $options['display_rule'] ) ? 'is-active' : ''; ?>" data-choice-value="exclude"><?php esc_html_e( 'Hide on Selected Pages', 'nasi-chat-click-to-connect' ); ?></button>
			</div>
			<input type="hidden" id="chnasi-field-display-rule" data-setting="display_rule" value="<?php echo esc_attr( $options['display_rule'] ); ?>" />
		</div>

		<div class="chnasi-field-row" id="chnasi-specific-pages-row" style="<?php echo ( 'all' === $options['display_rule'] ) ? 'display:none;' : ''; ?>">
			<label><?php esc_html_e( 'Select Pages / Posts', 'nasi-chat-click-to-connect' ); ?></label>
			<div class="chnasi-page-list">
				<?php if ( ! empty( $pages ) ) : ?>
					<p class="chnasi-page-list-group-label"><?php esc_html_e( 'Pages', 'nasi-chat-click-to-connect' ); ?></p>
					<?php foreach ( $pages as $page ) : ?>
						<label class="chnasi-checkbox-row">
							<input type="checkbox"
								class="chnasi-specific-page-checkbox"
								value="<?php echo esc_attr( $page->ID ); ?>"
								<?php checked( in_array( (int) $page->ID, (array) $options['specific_pages'], true ) ); ?> />
							<?php echo esc_html( $page->post_title ); ?>
						</label>
					<?php endforeach; ?>
				<?php endif; ?>

				<?php if ( ! empty( $posts ) ) : ?>
					<p class="chnasi-page-list-group-label"><?php esc_html_e( 'Posts', 'nasi-chat-click-to-connect' ); ?></p>
					<?php foreach ( $posts as $chnasi_post_item ) : ?>
						<label class="chnasi-checkbox-row">
							<input type="checkbox"
								class="chnasi-specific-page-checkbox"
								value="<?php echo esc_attr( $chnasi_post_item->ID ); ?>"
								<?php checked( in_array( (int) $chnasi_post_item->ID, (array) $options['specific_pages'], true ) ); ?> />
							<?php echo esc_html( $chnasi_post_item->post_title ); ?>
						</label>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
			<input type="hidden" id="chnasi-field-specific-pages" data-setting="specific_pages" value="<?php echo esc_attr( wp_json_encode( $options['specific_pages'] ) ); ?>" />
		</div>
	</div>

</section>
