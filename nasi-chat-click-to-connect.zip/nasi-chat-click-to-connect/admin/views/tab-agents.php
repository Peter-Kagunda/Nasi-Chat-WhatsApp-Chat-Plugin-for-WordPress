<?php
/**
 * Multi-agent settings tab.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="chnasi-tab-panel" data-tab-panel="agents">

	<div class="chnasi-card">
		<h2><?php esc_html_e( 'Multi-Agent Routing', 'nasi-chat-click-to-connect' ); ?></h2>
		<p class="chnasi-card-desc"><?php esc_html_e( 'Let visitors choose which team member or department to chat with, instead of a single number.', 'nasi-chat-click-to-connect' ); ?></p>

		<div class="chnasi-field-row chnasi-field-row-inline">
			<label class="chnasi-switch">
				<input type="checkbox" id="chnasi-field-multi-agent" data-setting="multi_agent_enabled" <?php checked( $options['multi_agent_enabled'] ); ?> />
				<span class="chnasi-switch-slider"></span>
			</label>
			<span><?php esc_html_e( 'Enable multi-agent panel', 'nasi-chat-click-to-connect' ); ?></span>
		</div>
	</div>

	<div class="chnasi-card" id="chnasi-agents-list-card">
		<div class="chnasi-card-header">
			<h2><?php esc_html_e( 'Team Members', 'nasi-chat-click-to-connect' ); ?></h2>
			<button type="button" class="button button-secondary" id="chnasi-add-agent-btn">
				<span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'Add Agent', 'nasi-chat-click-to-connect' ); ?>
			</button>
		</div>

		<div id="chnasi-agents-list">
			<?php if ( ! empty( $options['agents'] ) ) : ?>
				<?php foreach ( $options['agents'] as $chnasi_agent ) : ?>
					<?php require __DIR__ . '/partial-agent-row.php'; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>

		<p class="chnasi-empty-note" id="chnasi-agents-empty-note" style="<?php echo empty( $options['agents'] ) ? '' : 'display:none;'; ?>">
			<?php esc_html_e( 'No agents added yet. Click "Add Agent" to set up your team.', 'nasi-chat-click-to-connect' ); ?>
		</p>
	</div>

</section>
