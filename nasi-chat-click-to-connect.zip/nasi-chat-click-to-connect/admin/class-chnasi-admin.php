<?php
/**
 * Admin dashboard controller.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CHNASI_Admin
 *
 * Registers the admin menu/dashboard, handles settings AJAX requests,
 * and enqueues admin-only assets.
 */
class CHNASI_Admin {

	/**
	 * Settings accessor.
	 *
	 * @var CHNASI_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->settings = new CHNASI_Settings();

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_chnasi_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'wp_ajax_chnasi_reset_stats', array( $this, 'handle_reset_stats' ) );
		add_action( 'wp_ajax_chnasi_get_chart_data', array( $this, 'handle_get_chart_data' ) );
		add_filter( 'plugin_action_links_' . CHNASI_PLUGIN_BASENAME, array( $this, 'add_settings_link' ) );
	}

	/**
	 * Register the top-level admin menu page.
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Nasi Chat - Click to Connect', 'nasi-chat-click-to-connect' ),
			__( 'Nasi Chat', 'nasi-chat-click-to-connect' ),
			'manage_options',
			'chnasi-dashboard',
			array( $this, 'render_dashboard' ),
			$this->get_menu_icon(),
			58
		);
	}

	/**
	 * Build a base64 inline SVG for the admin menu icon.
	 *
	 * @return string
	 */
	private function get_menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="#a7aaad"><path d="M16.1 3C9 3 3.2 8.8 3.2 15.9c0 2.5.7 4.9 2 7L3 29l6.3-2.1c2 .9 4.2 1.4 6.5 1.4h.1c7.1 0 12.9-5.8 12.9-12.9C28.8 8.8 23 3 16.1 3zm0 23.6c-2.1 0-4.1-.6-5.9-1.6l-.4-.3-4.4 1.5 1.5-4.3-.3-.4c-1.1-1.8-1.7-3.9-1.7-6.1 0-6.3 5.1-11.3 11.3-11.3 3 0 5.9 1.2 8 3.3 2.1 2.1 3.3 5 3.3 8-.1 6.3-5.2 11.2-11.4 11.2z"/></svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Add a "Settings" link on the Plugins list screen.
	 *
	 * @param array $links Existing action links.
	 *
	 * @return array
	 */
	public function add_settings_link( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=chnasi-dashboard' ) ),
			esc_html__( 'Settings', 'nasi-chat-click-to-connect' )
		);

		array_unshift( $links, $settings_link );

		// Discreet upgrade link (plugins list only, no admin notices).
		$links[] = sprintf(
			'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
			esc_url( 'https://peterkagunda.com/product/nasi-chat-pro/' ),
			esc_html__( 'Upgrade to Pro', 'nasi-chat-click-to-connect' )
		);

		return $links;
	}

	/**
	 * Enqueue admin CSS/JS, scoped to the plugin's own dashboard screen only.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_chnasi-dashboard' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_media();

		wp_enqueue_style(
			'chnasi-admin',
			CHNASI_PLUGIN_URL . 'assets/css/admin.css',
			array( 'wp-color-picker' ),
			CHNASI_VERSION
		);

		wp_enqueue_script(
			'chnasi-admin',
			CHNASI_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery', 'wp-color-picker' ),
			CHNASI_VERSION,
			true
		);

		wp_localize_script(
			'chnasi-admin',
			'chnasiAdminData',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'chnasi_admin_nonce' ),
				'settings'   => $this->settings->get_all(),
				'strings'    => array(
					'saved'        => __( 'Settings saved successfully.', 'nasi-chat-click-to-connect' ),
					'error'        => __( 'Something went wrong. Please try again.', 'nasi-chat-click-to-connect' ),
					'confirmReset' => __( 'This will permanently delete all click analytics. Continue?', 'nasi-chat-click-to-connect' ),
					'chooseImage'  => __( 'Choose Icon', 'nasi-chat-click-to-connect' ),
					'useImage'     => __( 'Use this image', 'nasi-chat-click-to-connect' ),
				),
			)
		);
	}

	/**
	 * AJAX handler: save all dashboard settings.
	 */
	public function handle_save_settings() {
		check_ajax_referer( 'chnasi_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'nasi-chat-click-to-connect' ) ), 403 );
		}

		if ( ! isset( $_POST['settings'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No settings were submitted.', 'nasi-chat-click-to-connect' ) ) );
		}

		// The settings blob arrives as a JSON string; decode then let
		// CHNASI_Settings::sanitize() validate and sanitize every individual
		// field by type before anything is saved or used.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- raw JSON is decoded then fully validated/sanitized field-by-field in CHNASI_Settings::sanitize().
		$raw_json = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : '';
		$decoded  = json_decode( $raw_json, true );

		if ( ! is_array( $decoded ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid settings payload.', 'nasi-chat-click-to-connect' ) ) );
		}

		$saved = $this->settings->save( $decoded );

		wp_send_json_success(
			array(
				'message'  => __( 'Settings saved successfully.', 'nasi-chat-click-to-connect' ),
				'settings' => $saved,
			)
		);
	}

	/**
	 * AJAX handler: clear all click analytics data.
	 */
	public function handle_reset_stats() {
		check_ajax_referer( 'chnasi_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'nasi-chat-click-to-connect' ) ), 403 );
		}

		CHNASI_DB::clear_all_clicks();

		wp_send_json_success( array( 'message' => __( 'Analytics data cleared.', 'nasi-chat-click-to-connect' ) ) );
	}

	/**
	 * AJAX handler: fetch chart-ready analytics data for the dashboard.
	 */
	public function handle_get_chart_data() {
		check_ajax_referer( 'chnasi_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'nasi-chat-click-to-connect' ) ), 403 );
		}

		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 14;

		wp_send_json_success(
			array(
				'daily'      => CHNASI_DB::get_daily_click_totals( $days ),
				'by_agent'   => CHNASI_DB::get_clicks_by_agent(),
				'total'      => CHNASI_DB::get_click_count(),
				'total_days' => CHNASI_DB::get_click_count( $days ),
			)
		);
	}

	/**
	 * Render the main dashboard page shell.
	 */
	public function render_dashboard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$options       = $this->settings->get_all();
		$total_clicks  = CHNASI_DB::get_click_count();
		$clicks_7_days = CHNASI_DB::get_click_count( 7 );
		$pages         = get_pages( array( 'sort_column' => 'post_title' ) );
		$posts         = get_posts(
			array(
				'numberposts' => 100,
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);

		require CHNASI_PLUGIN_DIR . 'admin/views/dashboard.php';
	}
}
