/**
 * Nasi Chat - Admin Dashboard Behaviour
 */
( function ( $ ) {
	'use strict';

	var state = {
		settings: {},
		dirty: false,
	};

	$( function () {
		if ( 'undefined' === typeof chnasiAdminData ) {
			return;
		}

		state.settings = $.extend( true, {}, chnasiAdminData.settings );

		initTabs();
		initSimpleFields();
		initChoiceGroups();
		initColorPickers();
		initIconType();
		initMediaUploader();
		initVisibilityRules();
		initBusinessHours();
		initAgents();
		initSaveButton();
		initResetStats();
		updatePreviewBubble();
		loadChartData( 14 );

		$( '#chnasi-chart-range' ).on( 'change', function () {
			loadChartData( parseInt( $( this ).val(), 10 ) || 14 );
		} );
	} );

	/**
	 * Tab navigation.
	 */
	function initTabs() {
		$( '.chnasi-nav-item' ).on( 'click', function () {
			var tab = $( this ).data( 'tab' );

			$( '.chnasi-nav-item' ).removeClass( 'is-active' );
			$( this ).addClass( 'is-active' );

			$( '.chnasi-tab-panel' ).removeClass( 'is-active' );
			$( '[data-tab-panel="' + tab + '"]' ).addClass( 'is-active' );
		} );
	}

	/**
	 * Bind every plain input/select/textarea carrying a data-setting
	 * attribute directly to the in-memory settings object.
	 */
	function initSimpleFields() {
		$( document ).on( 'input change', '[data-setting]', function () {
			var $field = $( this );
			var key    = $field.data( 'setting' );

			if ( ! key ) {
				return;
			}

			// Skip fields whose value is managed by a more specific
			// handler (choice groups, hours, specific pages) to avoid
			// double-processing; those still carry data-setting so the
			// initial PHP-rendered value seeds state.settings correctly,
			// but their live updates happen in their own handlers.
			if ( $field.is( '[type="checkbox"]' ) ) {
				setSetting( key, $field.is( ':checked' ) );
			} else if ( $field.is( '[type="number"]' ) ) {
				setSetting( key, parseInt( $field.val(), 10 ) || 0 );
			} else if ( 'chnasi-field-business-hours' === $field.attr( 'id' ) || 'chnasi-field-specific-pages' === $field.attr( 'id' ) ) {
				try {
					setSetting( key, JSON.parse( $field.val() ) );
				} catch ( e ) {
					/* leave existing value on parse failure */
				}
			} else {
				setSetting( key, $field.val() );
			}

			if ( 'button_bg_color' === key || 'button_size' === key ) {
				updatePreviewBubble();
			}
		} );
	}

	/**
	 * Segmented "choice group" buttons (position, size, show_on, etc.)
	 * that write their selected value into a hidden input.
	 */
	function initChoiceGroups() {
		$( '.chnasi-choice-group' ).each( function () {
			var $group     = $( this );
			var settingKey = $group.data( 'setting-group' );
			var $hidden    = $group.siblings( 'input[data-setting="' + settingKey + '"]' );

			$group.on( 'click', '.chnasi-choice-btn', function () {
				var value = $( this ).data( 'choice-value' );

				$group.find( '.chnasi-choice-btn' ).removeClass( 'is-active' );
				$( this ).addClass( 'is-active' );
				$hidden.val( value );
				setSetting( settingKey, value );

				if ( 'icon_type' === settingKey ) {
					$( '#chnasi-custom-icon-row' ).toggle( 'custom' === value );
				}

				if ( 'display_rule' === settingKey ) {
					$( '#chnasi-specific-pages-row' ).toggle( 'all' !== value );
				}

				if ( 'button_size' === settingKey || 'position' === settingKey ) {
					updatePreviewBubble();
				}
			} );
		} );
	}

	/**
	 * Initialize WP core color pickers for color fields.
	 */
	function initColorPickers() {
		if ( ! $.fn.wpColorPicker ) {
			return;
		}

		$( '.chnasi-color-picker' ).wpColorPicker( {
			change: function ( event, ui ) {
				var key = $( event.target ).data( 'setting' );
				setSetting( key, ui.color.toString() );
				updatePreviewBubble();
			},
		} );
	}

	/**
	 * Show/hide the custom icon upload row based on the current icon type.
	 */
	function initIconType() {
		var current = $( '#chnasi-field-icon-type' ).val();
		$( '#chnasi-custom-icon-row' ).toggle( 'custom' === current );
	}

	/**
	 * WordPress media library integration for custom icon and agent avatars.
	 */
	function initMediaUploader() {
		$( '#chnasi-upload-icon-btn' ).on( 'click', function ( event ) {
			event.preventDefault();

			var frame = wp.media( {
				title: chnasiAdminData.strings.chooseImage,
				button: { text: chnasiAdminData.strings.useImage },
				multiple: false,
				library: { type: 'image' },
			} );

			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();

				$( '#chnasi-field-custom-icon-url' ).val( attachment.url );
				$( '#chnasi-custom-icon-preview' ).attr( 'src', attachment.url ).show();
				$( '#chnasi-remove-icon-btn' ).show();
				setSetting( 'custom_icon_url', attachment.url );
			} );

			frame.open();
		} );

		$( '#chnasi-remove-icon-btn' ).on( 'click', function ( event ) {
			event.preventDefault();
			$( '#chnasi-field-custom-icon-url' ).val( '' );
			$( '#chnasi-custom-icon-preview' ).attr( 'src', '' ).hide();
			$( this ).hide();
			setSetting( 'custom_icon_url', '' );
		} );

		// Delegated handler for per-agent avatar buttons (including
		// agents added dynamically after page load).
		$( document ).on( 'click', '.chnasi-agent-avatar-btn', function ( event ) {
			event.preventDefault();

			var $card = $( this ).closest( '[data-agent-row]' );

			var frame = wp.media( {
				title: chnasiAdminData.strings.chooseImage,
				button: { text: chnasiAdminData.strings.useImage },
				multiple: false,
				library: { type: 'image' },
			} );

			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();

				$card.find( '.chnasi-agent-avatar-url' ).val( attachment.url );
				$card.find( '.chnasi-agent-card-avatar-img' ).attr( 'src', attachment.url ).show();
				$card.find( '.chnasi-agent-card-avatar-placeholder' ).hide();
			} );

			frame.open();
		} );
	}

	/**
	 * Page/post display-rule checkboxes -> specific_pages hidden field.
	 */
	function initVisibilityRules() {
		var currentRule = $( '#chnasi-field-display-rule' ).val();
		$( '#chnasi-specific-pages-row' ).toggle( 'all' !== currentRule );

		$( document ).on( 'change', '.chnasi-specific-page-checkbox', function () {
			var ids = [];

			$( '.chnasi-specific-page-checkbox:checked' ).each( function () {
				ids.push( parseInt( $( this ).val(), 10 ) );
			} );

			$( '#chnasi-field-specific-pages' ).val( JSON.stringify( ids ) );
			setSetting( 'specific_pages', ids );
		} );
	}

	/**
	 * Weekly business hours table -> business_hours hidden field.
	 */
	function initBusinessHours() {
		function syncHours() {
			var hours = {};

			$( '#chnasi-hours-tbody tr' ).each( function () {
				var $row = $( this );
				var day  = $row.data( 'day' );

				hours[ day ] = {
					enabled: $row.find( '.chnasi-hours-enabled' ).is( ':checked' ),
					start: $row.find( '.chnasi-hours-start' ).val() || '08:00',
					end: $row.find( '.chnasi-hours-end' ).val() || '17:00',
				};
			} );

			$( '#chnasi-field-business-hours' ).val( JSON.stringify( hours ) );
			setSetting( 'business_hours', hours );
		}

		$( document ).on( 'change', '#chnasi-hours-tbody input', syncHours );
	}

	/**
	 * Agents list: add, remove, and serialize on save.
	 */
	function initAgents() {
		$( '#chnasi-add-agent-btn' ).on( 'click', function () {
			var template = document.getElementById( 'chnasi-agent-row-template' );
			var clone    = template.content.cloneNode( true );

			$( '#chnasi-agents-list' ).append( clone );
			$( '#chnasi-agents-empty-note' ).hide();
		} );

		$( document ).on( 'click', '.chnasi-agent-remove-btn', function () {
			$( this ).closest( '[data-agent-row]' ).remove();

			if ( 0 === $( '#chnasi-agents-list [data-agent-row]' ).length ) {
				$( '#chnasi-agents-empty-note' ).show();
			}
		} );
	}

	/**
	 * Read the current agent cards out of the DOM into a plain array.
	 *
	 * @return {Array} Agents.
	 */
	function collectAgents() {
		var agents = [];

		$( '#chnasi-agents-list [data-agent-row]' ).each( function ( index ) {
			var $card = $( this );
			var phone = $card.find( '.chnasi-agent-phone' ).val();

			if ( ! phone ) {
				return;
			}

			agents.push( {
				id: $card.data( 'agent-id' ) || ( 'agent_' + Date.now() + '_' + index ),
				name: $card.find( '.chnasi-agent-name' ).val(),
				role: $card.find( '.chnasi-agent-role' ).val(),
				phone_number: phone,
				message: $card.find( '.chnasi-agent-message' ).val(),
				avatar_url: $card.find( '.chnasi-agent-avatar-url' ).val(),
			} );
		} );

		return agents;
	}

	/**
	 * Update a key in the in-memory settings state and flag as dirty.
	 *
	 * @param {string} key   Setting key.
	 * @param {*}      value New value.
	 */
	function setSetting( key, value ) {
		state.settings[ key ] = value;
		state.dirty = true;
		$( '#chnasi-save-status' ).removeClass( 'is-error' ).text( '' );
	}

	/**
	 * Update the live preview bubble to reflect current color/size.
	 */
	function updatePreviewBubble() {
		var $bubble = $( '#chnasi-preview-bubble' );
		var color   = state.settings.button_bg_color || '#25D366';
		var sizes   = { small: '40px', medium: '48px', large: '56px' };
		var size    = sizes[ state.settings.button_size ] || sizes.medium;

		$bubble.css( {
			'background-color': color,
			width: size,
			height: size,
		} );
	}

	/**
	 * Wire up the top "Save Changes" button.
	 */
	function initSaveButton() {
		$( '#chnasi-save-btn' ).on( 'click', function () {
			state.settings.agents = collectAgents();

			var $status = $( '#chnasi-save-status' );
			var $btn    = $( this );

			$btn.prop( 'disabled', true );
			$status.removeClass( 'is-error' ).text( '' );

			$.ajax( {
				url: chnasiAdminData.ajaxUrl,
				method: 'POST',
				data: {
					action: 'chnasi_save_settings',
					nonce: chnasiAdminData.nonce,
					settings: JSON.stringify( state.settings ),
				},
			} )
				.done( function ( response ) {
					if ( response && response.success ) {
						state.dirty = false;
						$status.text( chnasiAdminData.strings.saved );
					} else {
						$status.addClass( 'is-error' ).text( chnasiAdminData.strings.error );
					}
				} )
				.fail( function () {
					$status.addClass( 'is-error' ).text( chnasiAdminData.strings.error );
				} )
				.always( function () {
					$btn.prop( 'disabled', false );
				} );
		} );

		// Warn before leaving with unsaved changes.
		window.addEventListener( 'beforeunload', function ( event ) {
			if ( state.dirty ) {
				event.preventDefault();
				event.returnValue = '';
			}
		} );
	}

	/**
	 * Reset analytics button.
	 */
	function initResetStats() {
		$( '#chnasi-reset-stats-btn' ).on( 'click', function () {
			if ( ! window.confirm( chnasiAdminData.strings.confirmReset ) ) {
				return;
			}

			var $btn = $( this );
			$btn.prop( 'disabled', true );

			$.ajax( {
				url: chnasiAdminData.ajaxUrl,
				method: 'POST',
				data: {
					action: 'chnasi_reset_stats',
					nonce: chnasiAdminData.nonce,
				},
			} )
				.done( function () {
					loadChartData( parseInt( $( '#chnasi-chart-range' ).val(), 10 ) || 14 );
				} )
				.always( function () {
					$btn.prop( 'disabled', false );
				} );
		} );
	}

	/**
	 * Load click analytics and render the chart, top-agents list,
	 * and the agent breakdown table.
	 *
	 * @param {number} days Number of days to include.
	 */
	function loadChartData( days ) {
		$.ajax( {
			url: chnasiAdminData.ajaxUrl,
			method: 'POST',
			data: {
				action: 'chnasi_get_chart_data',
				nonce: chnasiAdminData.nonce,
				days: days,
			},
		} ).done( function ( response ) {
			if ( ! response || ! response.success ) {
				return;
			}

			renderChart( response.data.daily );
			renderTopAgents( response.data.by_agent );
			renderAgentBreakdown( response.data.by_agent );
		} );
	}

	/**
	 * Draw a minimal line chart on the canvas using plain 2D drawing
	 * (no external chart library dependency).
	 *
	 * @param {Array} daily List of { click_date, total } rows.
	 */
	function renderChart( daily ) {
		var canvas = document.getElementById( 'chnasi-clicks-chart' );

		if ( ! canvas ) {
			return;
		}

		if ( ! daily || ! daily.length ) {
			$( '#chnasi-chart-empty' ).show();
			canvas.style.display = 'none';
			return;
		}

		$( '#chnasi-chart-empty' ).hide();
		canvas.style.display = '';

		var ctx           = canvas.getContext( '2d' );
		var dpr           = window.devicePixelRatio || 1;
		var displayWidth  = canvas.parentElement.clientWidth;
		var displayHeight = 220;

		canvas.width  = displayWidth * dpr;
		canvas.height = displayHeight * dpr;
		canvas.style.width  = displayWidth + 'px';
		canvas.style.height = displayHeight + 'px';
		ctx.scale( dpr, dpr );
		ctx.clearRect( 0, 0, displayWidth, displayHeight );

		var padding  = { top: 16, right: 16, bottom: 26, left: 30 };
		var chartW   = displayWidth - padding.left - padding.right;
		var chartH   = displayHeight - padding.top - padding.bottom;
		var maxTotal = Math.max.apply( null, daily.map( function ( row ) { return parseInt( row.total, 10 ); } ) ) || 1;
		var stepX    = daily.length > 1 ? chartW / ( daily.length - 1 ) : 0;

		// Grid lines.
		ctx.strokeStyle = '#e5e7eb';
		ctx.lineWidth   = 1;
		for ( var g = 0; g <= 4; g++ ) {
			var gy = padding.top + ( chartH / 4 ) * g;
			ctx.beginPath();
			ctx.moveTo( padding.left, gy );
			ctx.lineTo( padding.left + chartW, gy );
			ctx.stroke();
		}

		// Line + fill.
		ctx.beginPath();
		daily.forEach( function ( row, index ) {
			var x = padding.left + stepX * index;
			var y = padding.top + chartH - ( parseInt( row.total, 10 ) / maxTotal ) * chartH;

			if ( 0 === index ) {
				ctx.moveTo( x, y );
			} else {
				ctx.lineTo( x, y );
			}
		} );
		ctx.strokeStyle = '#25d366';
		ctx.lineWidth   = 2.5;
		ctx.stroke();

		var lastX = padding.left + stepX * ( daily.length - 1 );
		ctx.lineTo( lastX, padding.top + chartH );
		ctx.lineTo( padding.left, padding.top + chartH );
		ctx.closePath();
		ctx.fillStyle = 'rgba(37, 211, 102, 0.12)';
		ctx.fill();

		// Points.
		ctx.fillStyle = '#128c7e';
		daily.forEach( function ( row, index ) {
			var x = padding.left + stepX * index;
			var y = padding.top + chartH - ( parseInt( row.total, 10 ) / maxTotal ) * chartH;
			ctx.beginPath();
			ctx.arc( x, y, 3, 0, 2 * Math.PI );
			ctx.fill();
		} );

		// X-axis date labels (first, middle, last).
		ctx.fillStyle = '#6b7280';
		ctx.font      = '11px -apple-system, sans-serif';
		ctx.textAlign = 'center';

		var labelIndexes = [ 0, Math.floor( ( daily.length - 1 ) / 2 ), daily.length - 1 ];
		labelIndexes.forEach( function ( index ) {
			if ( ! daily[ index ] ) {
				return;
			}
			var x = padding.left + stepX * index;
			ctx.fillText( formatShortDate( daily[ index ].click_date ), x, displayHeight - 6 );
		} );
	}

	/**
	 * Format a YYYY-MM-DD date string as "Mon D".
	 *
	 * @param {string} dateStr Raw date string.
	 *
	 * @return {string}
	 */
	function formatShortDate( dateStr ) {
		var parts = dateStr.split( '-' );

		if ( 3 !== parts.length ) {
			return dateStr;
		}

		var months = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
		var month  = months[ parseInt( parts[1], 10 ) - 1 ] || '';

		return month + ' ' + parseInt( parts[2], 10 );
	}

	/**
	 * Render the "Top Agents" summary list on the Overview tab.
	 *
	 * @param {Array} byAgent List of { agent_id, total } rows.
	 */
	function renderTopAgents( byAgent ) {
		var $list = $( '#chnasi-top-agents-list' );

		if ( ! byAgent || ! byAgent.length ) {
			$list.html( '<p class="chnasi-empty-note">No agent click data yet.</p>' );
			return;
		}

		var html = '';
		byAgent.slice( 0, 5 ).forEach( function ( row ) {
			html += '<div class="chnasi-top-agent-row"><span>' + escapeHtml( row.agent_id ) + '</span>' +
				'<span class="chnasi-top-agent-count">' + escapeHtml( String( row.total ) ) + '</span></div>';
		} );

		$list.html( html );
	}

	/**
	 * Render the full agent breakdown table on the Analytics tab.
	 *
	 * @param {Array} byAgent List of { agent_id, total } rows.
	 */
	function renderAgentBreakdown( byAgent ) {
		var $tbody = $( '#chnasi-agent-breakdown-table tbody' );

		if ( ! byAgent || ! byAgent.length ) {
			$tbody.html( '<tr><td colspan="2" class="chnasi-empty-note">No click data yet.</td></tr>' );
			return;
		}

		var html = '';
		byAgent.forEach( function ( row ) {
			html += '<tr><td>' + escapeHtml( row.agent_id ) + '</td><td>' + escapeHtml( String( row.total ) ) + '</td></tr>';
		} );

		$tbody.html( html );
	}

	/**
	 * Minimal HTML-escaping helper for dynamically inserted text.
	 *
	 * @param {string} str Raw string.
	 *
	 * @return {string}
	 */
	function escapeHtml( str ) {
		return $( '<div>' ).text( str ).html();
	}
} )( jQuery );
