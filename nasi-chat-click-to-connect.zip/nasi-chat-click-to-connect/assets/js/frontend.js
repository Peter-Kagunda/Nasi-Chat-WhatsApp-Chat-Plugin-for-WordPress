/**
 * Nasi Chat - Frontend Behaviour
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var root = document.querySelector( '[data-chnasi-root]' );

		if ( ! root ) {
			return;
		}

		initTooltip( root );
		initAgentPanel( root );
		initClickTracking( root );
	} );

	/**
	 * Show the tooltip bubble after its configured delay, and allow
	 * the visitor to dismiss it (remembered for the current session).
	 *
	 * @param {HTMLElement} root Root button container.
	 */
	function initTooltip( root ) {
		var tooltip = root.querySelector( '.chnasi-tooltip' );

		if ( ! tooltip ) {
			return;
		}

		var dismissed = false;

		try {
			dismissed = window.sessionStorage.getItem( 'chnasi_tooltip_dismissed' ) === '1';
		} catch ( e ) {
			dismissed = false;
		}

		if ( dismissed ) {
			tooltip.classList.add( 'chnasi-hidden' );
			return;
		}

		var delaySeconds = parseInt( tooltip.getAttribute( 'data-chnasi-delay' ), 10 ) || 0;

		tooltip.style.opacity = '0';

		window.setTimeout( function () {
			tooltip.style.opacity = '';
		}, delaySeconds * 1000 );

		var closeBtn = tooltip.querySelector( '.chnasi-tooltip-close' );

		if ( closeBtn ) {
			closeBtn.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				event.stopPropagation();
				tooltip.classList.add( 'chnasi-hidden' );

				try {
					window.sessionStorage.setItem( 'chnasi_tooltip_dismissed', '1' );
				} catch ( e ) {
					/* Storage unavailable; ignore silently. */
				}
			} );
		}
	}

	/**
	 * Toggle the multi-agent selection panel when the main bubble
	 * is set up as a panel trigger rather than a direct link.
	 *
	 * @param {HTMLElement} root Root button container.
	 */
	function initAgentPanel( root ) {
		var trigger = root.querySelector( '[data-chnasi-toggle-panel="true"]' );
		var panel   = root.querySelector( '[data-chnasi-agent-panel]' );

		if ( ! trigger || ! panel ) {
			return;
		}

		function togglePanel( event ) {
			event.preventDefault();
			panel.classList.toggle( 'chnasi-open' );
		}

		trigger.addEventListener( 'click', togglePanel );
		trigger.addEventListener( 'keypress', function ( event ) {
			if ( 'Enter' === event.key || ' ' === event.key ) {
				togglePanel( event );
			}
		} );

		var closeBtn = panel.querySelector( '.chnasi-agent-panel-close' );

		if ( closeBtn ) {
			closeBtn.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				panel.classList.remove( 'chnasi-open' );
			} );
		}
	}

	/**
	 * Log a click server-side (for the analytics dashboard) and fire
	 * an optional Google Analytics event, for every outbound WhatsApp link.
	 *
	 * @param {HTMLElement} root Root button container.
	 */
	function initClickTracking( root ) {
		var links = root.querySelectorAll( 'a[href*="wa.me"]' );

		if ( ! links.length || 'undefined' === typeof chnasiFrontendData ) {
			return;
		}

		links.forEach( function ( link ) {
			link.addEventListener( 'click', function () {
				var agentId = link.getAttribute( 'data-chnasi-agent-id' ) || 'default';

				if ( chnasiFrontendData.clickTrackingEnabled ) {
					sendClickLog( agentId );
				}

				if ( chnasiFrontendData.gaTrackingEnabled && 'function' === typeof window.gtag ) {
					window.gtag( 'event', chnasiFrontendData.gaEventName || 'whatsapp_click', {
						agent_id: agentId,
					} );
				}
			} );
		} );
	}

	/**
	 * Send a beacon/AJAX request to the server to record the click.
	 *
	 * @param {string} agentId Identifier of the agent/button clicked.
	 */
	function sendClickLog( agentId ) {
		var formData = new FormData();

		formData.append( 'action', 'chnasi_log_click' );
		formData.append( 'nonce', chnasiFrontendData.nonce );
		formData.append( 'agent_id', agentId );
		formData.append( 'page_url', window.location.href );
		formData.append( 'referrer', document.referrer || '' );

		if ( navigator.sendBeacon ) {
			navigator.sendBeacon( chnasiFrontendData.ajaxUrl, formData );
			return;
		}

		fetch( chnasiFrontendData.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: formData,
		} ).catch( function () {
			/* Fail silently; click tracking is non-critical. */
		} );
	}
} )();
