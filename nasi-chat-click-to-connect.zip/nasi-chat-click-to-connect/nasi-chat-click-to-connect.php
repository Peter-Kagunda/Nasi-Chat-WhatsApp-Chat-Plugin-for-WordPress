<?php
/**
 * Plugin Name:       Nasi Chat - Click to Connect
 * Plugin URI:        https://peterkagunda.com
 * Description:       A modern, feature-rich floating WhatsApp chat button with a full admin dashboard, multi-agent routing, business hours, click analytics, and more.
 * Version:           1.0.0
 * Author:            Peter Kagunda
 * Author URI:        https://peterkagunda.com/
 * Text Domain:       nasi-chat-click-to-connect
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Core plugin constants.
 */
define( 'CHNASI_VERSION', '1.0.0' );
define( 'CHNASI_PLUGIN_FILE', __FILE__ );
define( 'CHNASI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CHNASI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CHNASI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'CHNASI_DB_VERSION', '1.0' );

/**
 * Load required plugin files.
 */
require_once CHNASI_PLUGIN_DIR . 'includes/class-chnasi-db.php';
require_once CHNASI_PLUGIN_DIR . 'includes/class-chnasi-settings.php';
require_once CHNASI_PLUGIN_DIR . 'includes/class-chnasi-frontend.php';
require_once CHNASI_PLUGIN_DIR . 'includes/class-chnasi-analytics.php';

if ( is_admin() ) {
	require_once CHNASI_PLUGIN_DIR . 'admin/class-chnasi-admin.php';
}

/**
 * Class CHNASI_Plugin
 *
 * Main plugin controller. Bootstraps all plugin components.
 */
final class CHNASI_Plugin {

	/**
	 * Single instance of this class.
	 *
	 * @var CHNASI_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Retrieve (or create) the single plugin instance.
	 *
	 * @return CHNASI_Plugin
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor. Wires up all plugin components.
	 */
	private function __construct() {
		$this->init_components();

		register_activation_hook( CHNASI_PLUGIN_FILE, array( $this, 'activate' ) );
		register_deactivation_hook( CHNASI_PLUGIN_FILE, array( $this, 'deactivate' ) );
	}

	/**
	 * Instantiate plugin components.
	 */
	private function init_components() {
		new CHNASI_Frontend();
		new CHNASI_Analytics();

		if ( is_admin() ) {
			new CHNASI_Admin();
		}
	}

	/**
	 * Runs on plugin activation.
	 * Creates the click-tracking table and seeds default settings.
	 */
	public function activate() {
		CHNASI_DB::create_tables();

		$settings = new CHNASI_Settings();
		$settings->maybe_seed_defaults();

		update_option( 'chnasi_db_version', CHNASI_DB_VERSION );

		if ( ! wp_next_scheduled( 'chnasi_daily_cleanup' ) ) {
			wp_schedule_event( time(), 'daily', 'chnasi_daily_cleanup' );
		}
	}

	/**
	 * Runs on plugin deactivation.
	 * Clears scheduled events. Data is intentionally preserved here;
	 * full removal happens in uninstall.php if the user deletes the plugin.
	 */
	public function deactivate() {
		wp_clear_scheduled_hook( 'chnasi_daily_cleanup' );
	}
}

/**
 * Kick off the plugin.
 *
 * @return CHNASI_Plugin
 */
function chnasi_run_plugin() {
	return CHNASI_Plugin::get_instance();
}
chnasi_run_plugin();
