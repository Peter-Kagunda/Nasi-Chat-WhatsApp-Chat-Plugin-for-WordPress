<?php
/**
 * Frontend rendering.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CHNASI_Frontend
 *
 * Renders the floating WhatsApp button on the public-facing site
 * and enqueues the assets it needs.
 */
class CHNASI_Frontend {

	/**
	 * Settings accessor.
	 *
	 * @var CHNASI_Settings
	 */
	private $settings;

	/**
	 * Analytics / business-hours helper.
	 *
	 * @var CHNASI_Analytics
	 */
	private $analytics;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->settings  = new CHNASI_Settings();
		$this->analytics = new CHNASI_Analytics();

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_button' ) );
	}

	/**
	 * Determine whether the button should render on the current request.
	 *
	 * @return bool
	 */
	private function should_display() {
		$options = $this->settings->get_all();

		if ( empty( $options['enabled'] ) || empty( $options['phone_number'] ) ) {
			return false;
		}

		// Device targeting.
		if ( 'desktop' === $options['show_on'] && wp_is_mobile() ) {
			return false;
		}

		if ( 'mobile' === $options['show_on'] && ! wp_is_mobile() ) {
			return false;
		}

		// Page include/exclude targeting.
		if ( 'include' === $options['display_rule'] || 'exclude' === $options['display_rule'] ) {
			$current_id = get_queried_object_id();
			$in_list    = in_array( absint( $current_id ), (array) $options['specific_pages'], true );

			if ( 'include' === $options['display_rule'] && ! $in_list ) {
				return false;
			}

			if ( 'exclude' === $options['display_rule'] && $in_list ) {
				return false;
			}
		}

		// Business hours: if offline behaviour is "hide_button" and we're closed, hide entirely.
		if ( $options['business_hours_enabled']
			&& 'hide_button' === $options['offline_behavior']
			&& ! $this->analytics->is_currently_open()
		) {
			return false;
		}

		/**
		 * Filters whether the Nasi Chat - Click to Connect button should display.
		 *
		 * @param bool  $display Whether to display the button.
		 * @param array $options Current plugin settings.
		 */
		return apply_filters( 'chnasi_should_display_button', true, $options );
	}

	/**
	 * Enqueue frontend CSS/JS, only when the button will actually render.
	 */
	public function enqueue_assets() {
		if ( ! $this->should_display() ) {
			return;
		}

		wp_enqueue_style(
			'chnasi-frontend',
			CHNASI_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			CHNASI_VERSION
		);

		wp_enqueue_script(
			'chnasi-frontend',
			CHNASI_PLUGIN_URL . 'assets/js/frontend.js',
			array(),
			CHNASI_VERSION,
			true
		);

		$options = $this->settings->get_all();

		wp_localize_script(
			'chnasi-frontend',
			'chnasiFrontendData',
			array(
				'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
				'nonce'            => wp_create_nonce( 'chnasi_public_nonce' ),
				'gaTrackingEnabled' => ! empty( $options['ga_tracking_enabled'] ),
				'gaEventName'      => $options['ga_event_name'],
				'clickTrackingEnabled' => ! empty( $options['click_tracking_enabled'] ),
			)
		);

		wp_add_inline_style( 'chnasi-frontend', $this->build_dynamic_css( $options ) );
	}

	/**
	 * Build a small block of dynamic CSS from the admin-configured
	 * colors, size, position, and z-index.
	 *
	 * @param array $options Current settings.
	 *
	 * @return string
	 */
	private function build_dynamic_css( $options ) {
		$bg_color   = sanitize_hex_color( $options['button_bg_color'] );
		$icon_color = sanitize_hex_color( $options['icon_color'] );
		$side       = ( 'left' === $options['position'] ) ? 'left' : 'right';
		$z_index    = absint( $options['z_index'] );

		$sizes = array(
			'small'  => '48px',
			'medium' => '56px',
			'large'  => '68px',
		);
		$size = isset( $sizes[ $options['button_size'] ] ) ? $sizes[ $options['button_size'] ] : $sizes['medium'];

		$css  = '.chnasi-whatsapp-float{';
		$css .= $side . ':24px;';
		$css .= 'z-index:' . $z_index . ';';
		$css .= '}';

		$css .= '.chnasi-whatsapp-float .chnasi-bubble{';
		$css .= 'width:' . esc_attr( $size ) . ';';
		$css .= 'height:' . esc_attr( $size ) . ';';

		if ( $bg_color ) {
			$css .= 'background-color:' . esc_attr( $bg_color ) . ';';
		}

		$css .= '}';

		if ( $icon_color ) {
			$css .= '.chnasi-whatsapp-float .chnasi-bubble svg path.chnasi-icon-fill{fill:' . esc_attr( $icon_color ) . ';}';
		}

		if ( 'left' === $side ) {
			$css .= '.chnasi-tooltip{left:0;right:auto;}';
			$css .= '.chnasi-agent-panel{left:0;right:auto;}';
		}

		return $css;
	}

	/**
	 * Render the floating button markup in the footer.
	 */
	public function render_button() {
		if ( ! $this->should_display() ) {
			return;
		}

		$options    = $this->settings->get_all();
		$is_open    = $this->analytics->is_currently_open();
		$show_offline_message = $options['business_hours_enabled']
			&& ! $is_open
			&& 'show_offline_message' === $options['offline_behavior'];

		$animation_class = 'chnasi-anim-' . sanitize_html_class( $options['animation'] );
		$size_class      = 'chnasi-size-' . sanitize_html_class( $options['button_size'] );
		$side_class      = 'chnasi-side-' . sanitize_html_class( $options['position'] );

		$agents = ( $options['multi_agent_enabled'] && ! empty( $options['agents'] ) ) ? $options['agents'] : array();

		?>
		<div class="chnasi-whatsapp-float <?php echo esc_attr( $side_class ); ?>" data-chnasi-root>

			<?php if ( $options['tooltip_enabled'] && empty( $agents ) ) : ?>
				<div class="chnasi-tooltip" data-chnasi-delay="<?php echo esc_attr( absint( $options['tooltip_delay'] ) ); ?>">
					<?php echo esc_html( $show_offline_message ? $options['offline_message'] : $options['tooltip_text'] ); ?>
					<button type="button" class="chnasi-tooltip-close" aria-label="<?php esc_attr_e( 'Close', 'nasi-chat-click-to-connect' ); ?>">&times;</button>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $agents ) ) : ?>
				<div class="chnasi-agent-panel" data-chnasi-agent-panel>
					<div class="chnasi-agent-panel-header">
						<span><?php echo esc_html( $options['button_label'] ); ?></span>
						<button type="button" class="chnasi-agent-panel-close" aria-label="<?php esc_attr_e( 'Close', 'nasi-chat-click-to-connect' ); ?>">&times;</button>
					</div>
					<div class="chnasi-agent-panel-body">
						<?php if ( $show_offline_message ) : ?>
							<p class="chnasi-offline-notice"><?php echo esc_html( $options['offline_message'] ); ?></p>
						<?php endif; ?>
						<?php foreach ( $agents as $agent ) : ?>
							<?php
							$wa_link = $this->build_whatsapp_link( $agent['phone_number'], $agent['message'] );
							?>
							<a href="<?php echo esc_url( $wa_link ); ?>"
								class="chnasi-agent-row"
								target="_blank"
								rel="noopener noreferrer"
								data-chnasi-agent-id="<?php echo esc_attr( $agent['id'] ); ?>">
								<?php if ( ! empty( $agent['avatar_url'] ) ) : ?>
									<img class="chnasi-agent-avatar" src="<?php echo esc_url( $agent['avatar_url'] ); ?>" alt="<?php echo esc_attr( $agent['name'] ); ?>" />
								<?php else : ?>
									<span class="chnasi-agent-avatar chnasi-agent-avatar-placeholder"><?php echo esc_html( strtoupper( substr( $agent['name'], 0, 1 ) ) ); ?></span>
								<?php endif; ?>
								<span class="chnasi-agent-info">
									<span class="chnasi-agent-name"><?php echo esc_html( $agent['name'] ); ?></span>
									<?php if ( ! empty( $agent['role'] ) ) : ?>
										<span class="chnasi-agent-role"><?php echo esc_html( $agent['role'] ); ?></span>
									<?php endif; ?>
								</span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php
			$main_link = $this->build_whatsapp_link( $options['phone_number'], $show_offline_message ? $options['offline_message'] : $options['welcome_message'] );
			?>
			<a href="<?php echo empty( $agents ) ? esc_url( $main_link ) : '#'; ?>"
				<?php if ( empty( $agents ) ) : ?>
					target="_blank" rel="noopener noreferrer"
				<?php else : ?>
					data-chnasi-toggle-panel="true" role="button" tabindex="0"
				<?php endif; ?>
				class="chnasi-bubble <?php echo esc_attr( $animation_class . ' ' . $size_class ); ?>"
				data-chnasi-agent-id="default"
				aria-label="<?php esc_attr_e( 'Chat on WhatsApp', 'nasi-chat-click-to-connect' ); ?>">
				<?php $this->render_icon( $options ); ?>
			</a>
		</div>
		<?php
	}

	/**
	 * Output the button icon: either the default WhatsApp glyph or a
	 * custom uploaded image.
	 *
	 * @param array $options Current settings.
	 */
	private function render_icon( $options ) {
		if ( 'custom' === $options['icon_type'] && ! empty( $options['custom_icon_url'] ) ) {
			printf(
				'<img src="%s" alt="%s" class="chnasi-custom-icon" />',
				esc_url( $options['custom_icon_url'] ),
				esc_attr__( 'Chat on WhatsApp', 'nasi-chat-click-to-connect' )
			);

			return;
		}
		?>
		<svg width="60%" height="60%" viewBox="0 0 1024 1024" fill="none" class="chnasi-icon-svg" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<path class="chnasi-icon-fill" d="M522 141C320.419 141 157 304.419 157 506C157 572.322 174.689 634.507 205.606 688.101L157 871L346.617 826.173C398.664 854.744 458.429 871 522 871C723.581 871 887 707.581 887 506C887 304.419 723.581 141 522 141ZM522 805.624C460.998 805.624 404.254 787.388 356.919 756.079L244.891 784.61L276.314 677.536C242.322 628.944 222.376 569.801 222.376 506C222.376 340.52 356.52 206.376 522 206.376C687.48 206.376 821.624 340.52 821.624 506C821.624 671.48 687.48 805.624 522 805.624Z" />
			<path class="chnasi-icon-fill" d="M607.527 554.187L695.836 595.825C699.892 597.737 702.488 601.847 702.123 606.315C701.163 617.934 696.506 641.226 675.626 662.099C616.692 721.033 510.876 654.36 506.577 651.778C480.554 637.799 455.815 619.09 432.374 595.642C408.933 572.201 390.217 547.462 376.238 521.439C373.656 517.14 306.983 411.317 365.917 352.39C386.796 331.51 410.082 326.853 421.701 325.893C426.169 325.528 430.279 328.124 432.192 332.18L473.829 420.489C475.802 424.667 474.937 429.635 471.666 432.899L440.627 463.938C433.915 470.65 431.942 481.1 436.565 489.393C447.887 509.705 463.115 529.259 480.764 547.252C498.757 564.894 518.318 580.129 538.623 591.451C546.917 596.075 557.366 594.108 564.078 587.389L595.117 556.35C598.381 553.086 603.35 552.221 607.527 554.187Z" />
		</svg>
		<?php
	}

	/**
	 * Build a wa.me deep link for a phone number and prefilled message.
	 *
	 * @param string $phone_number Phone number (digits, optional leading +).
	 * @param string $message      Prefilled message text.
	 *
	 * @return string
	 */
	private function build_whatsapp_link( $phone_number, $message ) {
		$digits = preg_replace( '/[^0-9]/', '', $phone_number );

		return sprintf(
			'https://wa.me/%1$s?text=%2$s',
			rawurlencode( $digits ),
			rawurlencode( $message )
		);
	}
}
