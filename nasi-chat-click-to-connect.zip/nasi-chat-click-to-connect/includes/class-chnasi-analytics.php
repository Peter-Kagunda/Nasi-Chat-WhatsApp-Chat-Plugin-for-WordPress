<?php
/**
 * Analytics and business-hours logic.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CHNASI_Analytics
 *
 * Handles the public click-logging AJAX endpoint and the
 * business-hours "are we open right now" calculation.
 */
class CHNASI_Analytics {

	/**
	 * Settings accessor.
	 *
	 * @var CHNASI_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->settings = new CHNASI_Settings();

		add_action( 'wp_ajax_chnasi_log_click', array( $this, 'handle_log_click' ) );
		add_action( 'wp_ajax_nopriv_chnasi_log_click', array( $this, 'handle_log_click' ) );
		add_action( 'chnasi_daily_cleanup', array( $this, 'run_daily_cleanup' ) );
	}

	/**
	 * AJAX handler: log a WhatsApp button click.
	 */
	public function handle_log_click() {
		check_ajax_referer( 'chnasi_public_nonce', 'nonce' );

		if ( ! $this->settings->get( 'click_tracking_enabled', true ) ) {
			wp_send_json_success( array( 'logged' => false ) );
		}

		$agent_id    = isset( $_POST['agent_id'] ) ? sanitize_text_field( wp_unslash( $_POST['agent_id'] ) ) : 'default';
		$page_url    = isset( $_POST['page_url'] ) ? esc_url_raw( wp_unslash( $_POST['page_url'] ) ) : '';
		$referrer    = isset( $_POST['referrer'] ) ? esc_url_raw( wp_unslash( $_POST['referrer'] ) ) : '';
		$device_type = wp_is_mobile() ? 'mobile' : 'desktop';

		CHNASI_DB::insert_click(
			array(
				'agent_id'    => $agent_id,
				'page_url'    => $page_url,
				'referrer'    => $referrer,
				'device_type' => $device_type,
			)
		);

		wp_send_json_success( array( 'logged' => true ) );
	}

	/**
	 * Determine whether the business is currently "open" based on the
	 * configured weekly schedule and timezone.
	 *
	 * @return bool True if open (or if business hours are disabled).
	 */
	public function is_currently_open() {
		if ( ! $this->settings->get( 'business_hours_enabled', false ) ) {
			return true;
		}

		$timezone_string = $this->settings->get( 'timezone_string', 'Africa/Nairobi' );

		try {
			$timezone = new DateTimeZone( $timezone_string );
		} catch ( Exception $e ) {
			$timezone = new DateTimeZone( 'UTC' );
		}

		$now      = new DateTime( 'now', $timezone );
		$day_key  = strtolower( $now->format( 'l' ) );
		$hours    = $this->settings->get( 'business_hours', array() );
		$today    = isset( $hours[ $day_key ] ) ? $hours[ $day_key ] : null;

		if ( empty( $today ) || empty( $today['enabled'] ) ) {
			return false;
		}

		$current_minutes = ( (int) $now->format( 'H' ) * 60 ) + (int) $now->format( 'i' );
		$start_minutes   = $this->time_to_minutes( $today['start'] );
		$end_minutes     = $this->time_to_minutes( $today['end'] );

		return ( $current_minutes >= $start_minutes && $current_minutes <= $end_minutes );
	}

	/**
	 * Convert an HH:MM string into total minutes.
	 *
	 * @param string $time Time string, e.g. "08:30".
	 *
	 * @return int
	 */
	private function time_to_minutes( $time ) {
		$parts = explode( ':', $time );

		if ( 2 !== count( $parts ) ) {
			return 0;
		}

		return ( (int) $parts[0] * 60 ) + (int) $parts[1];
	}

	/**
	 * Scheduled daily cleanup: prune click logs older than one year.
	 */
	public function run_daily_cleanup() {
		CHNASI_DB::prune_old_clicks( 365 );
	}
}
