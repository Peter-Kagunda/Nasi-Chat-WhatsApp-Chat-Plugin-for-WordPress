<?php
/**
 * Database handler.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CHNASI_DB
 *
 * Handles custom table creation and low-level click log queries.
 *
 * Every method below builds its table name from `$wpdb->prefix`
 * (see get_clicks_table()), so it is never user-controllable. Table/column
 * identifiers can't be bound with $wpdb->prepare()'s value placeholders,
 * and the %i identifier placeholder isn't an option since this plugin
 * supports WordPress 5.8+ (%i requires 6.2+). Each table name is instead
 * escaped with esc_sql() and assembled into its own $sql variable on a
 * line by itself, before that variable is ever passed to $wpdb->prepare(),
 * $wpdb->get_var(), $wpdb->get_results(), or $wpdb->query(); any
 * user-influenced value (e.g. a day count) is always bound as a
 * placeholder through $wpdb->prepare(). Building the query into a plain
 * variable first, rather than concatenating it inline as a call argument,
 * keeps each query's only free-standing risk (the escaped identifier)
 * isolated to one line, so it can be reviewed and annotated with
 * phpcs:ignore on its own.
 */
class CHNASI_DB {

	/**
	 * Get the fully-qualified click log table name.
	 *
	 * @return string
	 */
	public static function get_clicks_table() {
		global $wpdb;

		return $wpdb->prefix . 'chnasi_click_logs';
	}

	/**
	 * Create (or upgrade) the plugin's custom database tables.
	 */
	public static function create_tables() {
		global $wpdb;

		$table_name      = esc_sql( self::get_clicks_table() );
		$charset_collate = $wpdb->get_charset_collate();

		$sql = 'CREATE TABLE ' . $table_name . ' (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			agent_id VARCHAR(64) DEFAULT \'default\',
			page_url TEXT NOT NULL,
			referrer TEXT NULL,
			device_type VARCHAR(20) DEFAULT \'desktop\',
			clicked_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY clicked_at (clicked_at),
			KEY agent_id (agent_id)
		) ' . $charset_collate . ';';

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Insert a click log record.
	 *
	 * @param array $data Click data (agent_id, page_url, referrer, device_type).
	 *
	 * @return int|false The number of rows inserted, or false on error.
	 */
	public static function insert_click( $data ) {
		global $wpdb;

		// Writing to the plugin's own custom table; not cacheable by design.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->insert(
			self::get_clicks_table(),
			array(
				'agent_id'    => isset( $data['agent_id'] ) ? sanitize_text_field( $data['agent_id'] ) : 'default',
				'page_url'    => isset( $data['page_url'] ) ? esc_url_raw( $data['page_url'] ) : '',
				'referrer'    => isset( $data['referrer'] ) ? esc_url_raw( $data['referrer'] ) : '',
				'device_type' => isset( $data['device_type'] ) ? sanitize_text_field( $data['device_type'] ) : 'desktop',
				'clicked_at'  => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Get total click count, optionally filtered by a number of days.
	 *
	 * @param int|null $days Number of days to look back, or null for all-time.
	 *
	 * @return int
	 */
	public static function get_click_count( $days = null ) {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );

		if ( null === $days ) {
			// Table name is escaped via esc_sql() and is never user input, so it
			// is built into the query string here rather than through a
			// placeholder (identifiers can't be bound with $wpdb->prepare()).
			$sql = 'SELECT COUNT(id) FROM ' . $table;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $sql );
		}

		$days = absint( $days );

		// Table name is escaped via esc_sql() and is never user input. $days is
		// the only user-influenced value, and it is bound via $wpdb->prepare().
		// The identifier is concatenated into the query string (rather than a
		// literal) only because it is dynamic (site table prefix); it is never
		// derived from request input, so this is not a SQL-injection risk.
		$sql = 'SELECT COUNT(id) FROM ' . $table . ' WHERE clicked_at >= DATE_SUB(NOW(), INTERVAL %d DAY)';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $days ) );
	}

	/**
	 * Get daily click totals for the last N days, formatted for charting.
	 *
	 * @param int $days Number of days to include.
	 *
	 * @return array List of ( date, total ) associative rows.
	 */
	public static function get_daily_click_totals( $days = 14 ) {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );
		$days  = absint( $days );

		// Table name is escaped via esc_sql() and is never user input. $days is
		// the only user-influenced value, and it is bound via $wpdb->prepare().
		// The identifier is concatenated into the query string (rather than a
		// literal) only because it is dynamic (site table prefix); it is never
		// derived from request input, so this is not a SQL-injection risk.
		$sql = 'SELECT DATE(clicked_at) AS click_date, COUNT(id) AS total'
			. ' FROM ' . $table
			. ' WHERE clicked_at >= DATE_SUB(NOW(), INTERVAL %d DAY)'
			. ' GROUP BY click_date'
			. ' ORDER BY click_date ASC';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( $wpdb->prepare( $sql, $days ), ARRAY_A );

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Get click totals grouped by agent.
	 *
	 * @return array
	 */
	public static function get_clicks_by_agent() {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );

		// Table name is escaped via esc_sql() and is never user input; there are
		// no bindable values, so $wpdb->prepare() is not applicable here. The
		// identifier is concatenated into the query string (rather than a
		// literal) only because it is dynamic (site table prefix); it is never
		// derived from request input, so this is not a SQL-injection risk.
		$sql = 'SELECT agent_id, COUNT(id) AS total FROM ' . $table . ' GROUP BY agent_id ORDER BY total DESC';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( $sql, ARRAY_A );

		return is_array( $results ) ? $results : array();
	}

	/**
	 * Delete click logs older than a given number of days.
	 *
	 * @param int $days Retention period in days.
	 */
	public static function prune_old_clicks( $days = 365 ) {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );
		$days  = absint( $days );

		// Table name is escaped via esc_sql() and is never user input. $days is
		// the only user-influenced value, and it is bound via $wpdb->prepare().
		// The identifier is concatenated into the query string (rather than a
		// literal) only because it is dynamic (site table prefix); it is never
		// derived from request input, so this is not a SQL-injection risk.
		$sql = 'DELETE FROM ' . $table . ' WHERE clicked_at < DATE_SUB(NOW(), INTERVAL %d DAY)';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$wpdb->query( $wpdb->prepare( $sql, $days ) );
	}

	/**
	 * Truncate all click logs.
	 */
	public static function clear_all_clicks() {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );

		// Table name is escaped via esc_sql() and is never user input; there are
		// no bindable values, so $wpdb->prepare() is not applicable here.
		$sql = 'TRUNCATE TABLE ' . $table;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $sql );
	}

	/**
	 * Drop the plugin's custom tables entirely (used on uninstall).
	 */
	public static function drop_tables() {
		global $wpdb;

		$table = esc_sql( self::get_clicks_table() );

		// Table name is escaped via esc_sql() and is never user input; there are
		// no bindable values, so $wpdb->prepare() is not applicable here.
		$sql = 'DROP TABLE IF EXISTS ' . $table;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( $sql );
	}
}
