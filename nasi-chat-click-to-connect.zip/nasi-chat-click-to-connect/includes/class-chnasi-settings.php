<?php
/**
 * Settings handler.
 *
 * @package Nasi_Chat
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CHNASI_Settings
 *
 * Central place for reading, writing, sanitizing and defaulting
 * every option the plugin uses. All settings live in a single
 * option ( 'chnasi_settings' ) as an associative array.
 */
class CHNASI_Settings {

	/**
	 * The option name used to store all plugin settings.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'chnasi_settings';

	/**
	 * Get the full default settings array.
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return array(
			// General.
			'enabled'                => false,
			'phone_number'           => '',
			'welcome_message'        => __( 'Hello! How can we help you today?', 'nasi-chat-click-to-connect' ),
			'button_label'           => __( 'Chat with us', 'nasi-chat-click-to-connect' ),

			// Appearance.
			'position'               => 'right',
			'button_size'            => 'medium',
			'button_bg_color'        => '#25D366',
			'icon_color'             => '#FFFFFF',
			'animation'              => 'pulse',
			'z_index'                => 9999,
			'icon_type'              => 'default',
			'custom_icon_url'        => '',

			// Tooltip / chat bubble.
			'tooltip_enabled'        => true,
			'tooltip_text'           => __( 'Need help? Chat with us!', 'nasi-chat-click-to-connect' ),
			'tooltip_delay'          => 3,

			// Visibility.
			'show_on'                => 'all',
			'display_rule'           => 'all',
			'specific_pages'         => array(),

			// Business hours.
			'business_hours_enabled' => false,
			'timezone_string'        => 'Africa/Nairobi',
			'business_hours'         => self::get_default_hours(),
			'offline_behavior'       => 'show_offline_message',
			'offline_message'        => __( "We're currently offline. Leave us a message and we'll get back to you soon!", 'nasi-chat-click-to-connect' ),

			// Multi-agent routing.
			'multi_agent_enabled'    => false,
			'agent_display_mode'     => 'list',
			'agents'                 => array(),

			// Analytics / tracking.
			'click_tracking_enabled' => true,
			'ga_tracking_enabled'    => false,
			'ga_event_name'          => 'whatsapp_click',

			// Advanced.
			'exclude_admin_bar_users' => false,
		);
	}

	/**
	 * Default weekly business hours schedule.
	 *
	 * @return array
	 */
	public static function get_default_hours() {
		$days    = array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' );
		$default = array();

		foreach ( $days as $day ) {
			$default[ $day ] = array(
				'enabled' => in_array( $day, array( 'saturday', 'sunday' ), true ) ? false : true,
				'start'   => '08:00',
				'end'     => '17:00',
			);
		}

		return $default;
	}

	/**
	 * Get all current settings, merged with defaults so new keys
	 * added in future versions always have a safe fallback.
	 *
	 * @return array
	 */
	public function get_all() {
		$saved = get_option( self::OPTION_NAME, array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		return wp_parse_args( $saved, self::get_defaults() );
	}

	/**
	 * Get a single setting value by key.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $fallback Fallback value if not found.
	 *
	 * @return mixed
	 */
	public function get( $key, $fallback = null ) {
		$all = $this->get_all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Seed the settings option with defaults if it doesn't exist yet.
	 * Called on plugin activation. Never overwrites existing settings.
	 */
	public function maybe_seed_defaults() {
		if ( false === get_option( self::OPTION_NAME, false ) ) {
			add_option( self::OPTION_NAME, self::get_defaults() );
		}
	}

	/**
	 * Sanitize and persist a raw settings array (e.g. from $_POST).
	 *
	 * @param array $raw_input Raw, unsanitized input.
	 *
	 * @return array The sanitized settings that were saved.
	 */
	public function save( $raw_input ) {
		$sanitized = $this->sanitize( $raw_input );

		update_option( self::OPTION_NAME, $sanitized );

		return $sanitized;
	}

	/**
	 * Sanitize a raw settings array against the known schema.
	 *
	 * @param array $input Raw input.
	 *
	 * @return array Sanitized settings, merged over current values.
	 */
	public function sanitize( $input ) {
		$current    = $this->get_all();
		$sanitized  = $current;
		$allowed_positions = array( 'left', 'right' );
		$allowed_sizes     = array( 'small', 'medium', 'large' );
		$allowed_animations = array( 'none', 'pulse', 'bounce', 'shake', 'fade' );
		$allowed_show_on   = array( 'all', 'desktop', 'mobile' );
		$allowed_display_rule = array( 'all', 'include', 'exclude' );
		$allowed_offline   = array( 'show_offline_message', 'hide_button' );
		$allowed_icon_type = array( 'default', 'custom' );
		$allowed_agent_display = array( 'list', 'round_robin' );

		if ( isset( $input['enabled'] ) ) {
			$sanitized['enabled'] = (bool) $input['enabled'];
		}

		if ( isset( $input['phone_number'] ) ) {
			$sanitized['phone_number'] = $this->sanitize_phone( $input['phone_number'] );
		}

		if ( isset( $input['welcome_message'] ) ) {
			$sanitized['welcome_message'] = sanitize_textarea_field( $input['welcome_message'] );
		}

		if ( isset( $input['button_label'] ) ) {
			$sanitized['button_label'] = sanitize_text_field( $input['button_label'] );
		}

		if ( isset( $input['position'] ) && in_array( $input['position'], $allowed_positions, true ) ) {
			$sanitized['position'] = $input['position'];
		}

		if ( isset( $input['button_size'] ) && in_array( $input['button_size'], $allowed_sizes, true ) ) {
			$sanitized['button_size'] = $input['button_size'];
		}

		if ( isset( $input['button_bg_color'] ) ) {
			$sanitized['button_bg_color'] = sanitize_hex_color( $input['button_bg_color'] ) ? $input['button_bg_color'] : $current['button_bg_color'];
		}

		if ( isset( $input['icon_color'] ) ) {
			$sanitized['icon_color'] = sanitize_hex_color( $input['icon_color'] ) ? $input['icon_color'] : $current['icon_color'];
		}

		if ( isset( $input['animation'] ) && in_array( $input['animation'], $allowed_animations, true ) ) {
			$sanitized['animation'] = $input['animation'];
		}

		if ( isset( $input['z_index'] ) ) {
			$sanitized['z_index'] = absint( $input['z_index'] );
		}

		if ( isset( $input['icon_type'] ) && in_array( $input['icon_type'], $allowed_icon_type, true ) ) {
			$sanitized['icon_type'] = $input['icon_type'];
		}

		if ( isset( $input['custom_icon_url'] ) ) {
			$sanitized['custom_icon_url'] = esc_url_raw( $input['custom_icon_url'] );
		}

		if ( isset( $input['tooltip_enabled'] ) ) {
			$sanitized['tooltip_enabled'] = (bool) $input['tooltip_enabled'];
		}

		if ( isset( $input['tooltip_text'] ) ) {
			$sanitized['tooltip_text'] = sanitize_text_field( $input['tooltip_text'] );
		}

		if ( isset( $input['tooltip_delay'] ) ) {
			$sanitized['tooltip_delay'] = absint( $input['tooltip_delay'] );
		}

		if ( isset( $input['show_on'] ) && in_array( $input['show_on'], $allowed_show_on, true ) ) {
			$sanitized['show_on'] = $input['show_on'];
		}

		if ( isset( $input['display_rule'] ) && in_array( $input['display_rule'], $allowed_display_rule, true ) ) {
			$sanitized['display_rule'] = $input['display_rule'];
		}

		if ( isset( $input['specific_pages'] ) && is_array( $input['specific_pages'] ) ) {
			$sanitized['specific_pages'] = array_map( 'absint', $input['specific_pages'] );
		}

		if ( isset( $input['business_hours_enabled'] ) ) {
			$sanitized['business_hours_enabled'] = (bool) $input['business_hours_enabled'];
		}

		if ( isset( $input['timezone_string'] ) ) {
			$sanitized['timezone_string'] = sanitize_text_field( $input['timezone_string'] );
		}

		if ( isset( $input['business_hours'] ) && is_array( $input['business_hours'] ) ) {
			$sanitized['business_hours'] = $this->sanitize_business_hours( $input['business_hours'] );
		}

		if ( isset( $input['offline_behavior'] ) && in_array( $input['offline_behavior'], $allowed_offline, true ) ) {
			$sanitized['offline_behavior'] = $input['offline_behavior'];
		}

		if ( isset( $input['offline_message'] ) ) {
			$sanitized['offline_message'] = sanitize_textarea_field( $input['offline_message'] );
		}

		if ( isset( $input['multi_agent_enabled'] ) ) {
			$sanitized['multi_agent_enabled'] = (bool) $input['multi_agent_enabled'];
		}

		if ( isset( $input['agent_display_mode'] ) && in_array( $input['agent_display_mode'], $allowed_agent_display, true ) ) {
			$sanitized['agent_display_mode'] = $input['agent_display_mode'];
		}

		if ( isset( $input['agents'] ) && is_array( $input['agents'] ) ) {
			$sanitized['agents'] = $this->sanitize_agents( $input['agents'] );
		}

		if ( isset( $input['click_tracking_enabled'] ) ) {
			$sanitized['click_tracking_enabled'] = (bool) $input['click_tracking_enabled'];
		}

		if ( isset( $input['ga_tracking_enabled'] ) ) {
			$sanitized['ga_tracking_enabled'] = (bool) $input['ga_tracking_enabled'];
		}

		if ( isset( $input['ga_event_name'] ) ) {
			$sanitized['ga_event_name'] = sanitize_key( $input['ga_event_name'] );
		}

		if ( isset( $input['exclude_admin_bar_users'] ) ) {
			$sanitized['exclude_admin_bar_users'] = (bool) $input['exclude_admin_bar_users'];
		}

		return $sanitized;
	}

	/**
	 * Sanitize a phone number down to digits (and a leading +).
	 *
	 * @param string $raw_number Raw phone number input.
	 *
	 * @return string
	 */
	public function sanitize_phone( $raw_number ) {
		$number = sanitize_text_field( $raw_number );
		$number = preg_replace( '/[^0-9+]/', '', $number );

		return $number;
	}

	/**
	 * Sanitize the weekly business hours array.
	 *
	 * @param array $hours Raw business hours input.
	 *
	 * @return array
	 */
	private function sanitize_business_hours( $hours ) {
		$clean = array();
		$days  = array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' );

		foreach ( $days as $day ) {
			$row = isset( $hours[ $day ] ) && is_array( $hours[ $day ] ) ? $hours[ $day ] : array();

			$clean[ $day ] = array(
				'enabled' => ! empty( $row['enabled'] ),
				'start'   => isset( $row['start'] ) ? $this->sanitize_time( $row['start'] ) : '08:00',
				'end'     => isset( $row['end'] ) ? $this->sanitize_time( $row['end'] ) : '17:00',
			);
		}

		return $clean;
	}

	/**
	 * Validate an HH:MM time string.
	 *
	 * @param string $time Raw time string.
	 *
	 * @return string
	 */
	private function sanitize_time( $time ) {
		$time = sanitize_text_field( $time );

		if ( preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $time ) ) {
			return $time;
		}

		return '08:00';
	}

	/**
	 * Sanitize the multi-agent list.
	 *
	 * @param array $agents Raw agents array.
	 *
	 * @return array
	 */
	private function sanitize_agents( $agents ) {
		$clean = array();

		foreach ( $agents as $agent ) {
			if ( ! is_array( $agent ) || empty( $agent['phone_number'] ) ) {
				continue;
			}

			$clean[] = array(
				'id'           => isset( $agent['id'] ) ? sanitize_key( $agent['id'] ) : 'agent_' . uniqid(),
				'name'         => isset( $agent['name'] ) ? sanitize_text_field( $agent['name'] ) : '',
				'role'         => isset( $agent['role'] ) ? sanitize_text_field( $agent['role'] ) : '',
				'phone_number' => $this->sanitize_phone( $agent['phone_number'] ),
				'message'      => isset( $agent['message'] ) ? sanitize_textarea_field( $agent['message'] ) : '',
				'avatar_url'   => isset( $agent['avatar_url'] ) ? esc_url_raw( $agent['avatar_url'] ) : '',
			);
		}

		return $clean;
	}
}
